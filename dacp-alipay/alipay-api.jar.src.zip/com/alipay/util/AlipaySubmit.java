/*     */ package com.alipay.util;
/*     */ 
/*     */ import com.alipay.config.AlipayConfig;
/*     */ import com.alipay.sign.MD5;
/*     */ import com.alipay.util.httpClient.HttpProtocolHandler;
/*     */ import com.alipay.util.httpClient.HttpRequest;
/*     */ import com.alipay.util.httpClient.HttpResponse;
/*     */ import com.alipay.util.httpClient.HttpResultType;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentException;
/*     */ import org.dom4j.Node;
/*     */ import org.dom4j.io.SAXReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AlipaySubmit
/*     */ {
/*     */   private static final String ALIPAY_GATEWAY_NEW = "https://mapi.alipay.com/gateway.do?";
/*     */   
/*     */   public static String buildRequestMysign(Map<String, String> sPara)
/*     */   {
/*  47 */     String prestr = AlipayCore.createLinkString(sPara);
/*  48 */     String mysign = "";
/*  49 */     if (AlipayConfig.sign_type_md5.equals("MD5")) {
/*  50 */       mysign = MD5.sign(prestr, AlipayConfig.private_key, AlipayConfig.input_charset);
/*     */     }
/*  52 */     return mysign;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map<String, String> buildRequestPara(Map<String, String> sParaTemp)
/*     */   {
/*  62 */     Map<String, String> sPara = AlipayCore.paraFilter(sParaTemp);
/*     */     
/*  64 */     String mysign = buildRequestMysign(sPara);
/*     */     
/*     */ 
/*  67 */     sPara.put("sign", mysign);
/*  68 */     sPara.put("sign_type", AlipayConfig.sign_type_md5);
/*     */     
/*  70 */     return sPara;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String buildRequest(Map<String, String> sParaTemp, String strMethod, String strButtonName)
/*     */   {
/*  82 */     Map<String, String> sPara = buildRequestPara(sParaTemp);
/*  83 */     List<String> keys = new ArrayList(sPara.keySet());
/*     */     
/*  85 */     StringBuffer sbHtml = new StringBuffer();
/*     */     
/*  87 */     sbHtml.append("<form id=\"alipaysubmit\" name=\"alipaysubmit\" action=\"https://mapi.alipay.com/gateway.do?_input_charset=" + 
/*  88 */       AlipayConfig.input_charset + "\" method=\"" + strMethod + 
/*  89 */       "\">");
/*     */     
/*  91 */     for (int i = 0; i < keys.size(); i++) {
/*  92 */       String name = (String)keys.get(i);
/*  93 */       String value = (String)sPara.get(name);
/*     */       
/*  95 */       sbHtml.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + value + "\"/>");
/*     */     }
/*     */     
/*     */ 
/*  99 */     sbHtml.append("<input type=\"submit\" value=\"" + strButtonName + "\" style=\"display:none;\"></form>");
/* 100 */     sbHtml.append("<script>document.forms['alipaysubmit'].submit();</script>");
/*     */     
/* 102 */     return sbHtml.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String buildRequest(Map<String, String> sParaTemp, String strMethod, String strButtonName, String strParaFileName)
/*     */   {
/* 115 */     Map<String, String> sPara = buildRequestPara(sParaTemp);
/* 116 */     List<String> keys = new ArrayList(sPara.keySet());
/*     */     
/* 118 */     StringBuffer sbHtml = new StringBuffer();
/*     */     
/* 120 */     sbHtml.append("<form id=\"alipaysubmit\" name=\"alipaysubmit\"  enctype=\"multipart/form-data\" action=\"https://mapi.alipay.com/gateway.do?_input_charset=" + 
/* 121 */       AlipayConfig.input_charset + "\" method=\"" + strMethod + 
/* 122 */       "\">");
/*     */     
/* 124 */     for (int i = 0; i < keys.size(); i++) {
/* 125 */       String name = (String)keys.get(i);
/* 126 */       String value = (String)sPara.get(name);
/*     */       
/* 128 */       sbHtml.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + value + "\"/>");
/*     */     }
/*     */     
/* 131 */     sbHtml.append("<input type=\"file\" name=\"" + strParaFileName + "\" />");
/*     */     
/*     */ 
/* 134 */     sbHtml.append("<input type=\"submit\" value=\"" + strButtonName + "\" style=\"display:none;\"></form>");
/*     */     
/* 136 */     return sbHtml.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String buildRequest(String strParaFileName, String strFilePath, Map<String, String> sParaTemp)
/*     */     throws Exception
/*     */   {
/* 151 */     Map<String, String> sPara = buildRequestPara(sParaTemp);
/*     */     
/* 153 */     HttpProtocolHandler httpProtocolHandler = HttpProtocolHandler.getInstance();
/*     */     
/* 155 */     HttpRequest request = new HttpRequest(HttpResultType.BYTES);
/*     */     
/* 157 */     request.setCharset(AlipayConfig.input_charset);
/*     */     
/* 159 */     request.setParameters(generatNameValuePair(sPara));
/* 160 */     request.setUrl("https://mapi.alipay.com/gateway.do?_input_charset=" + AlipayConfig.input_charset);
/*     */     
/* 162 */     HttpResponse response = httpProtocolHandler.execute(request, strParaFileName, strFilePath);
/* 163 */     if (response == null) {
/* 164 */       return null;
/*     */     }
/*     */     
/* 167 */     String strResult = response.getStringResult();
/*     */     
/* 169 */     return strResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NameValuePair[] generatNameValuePair(Map<String, String> properties)
/*     */   {
/* 178 */     NameValuePair[] nameValuePair = new NameValuePair[properties.size()];
/* 179 */     int i = 0;
/* 180 */     for (Map.Entry<String, String> entry : properties.entrySet()) {
/* 181 */       nameValuePair[(i++)] = new NameValuePair((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */     
/* 184 */     return nameValuePair;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String query_timestamp()
/*     */     throws MalformedURLException, DocumentException, IOException
/*     */   {
/* 199 */     String strUrl = "https://mapi.alipay.com/gateway.do?service=query_timestamp&partner=" + AlipayConfig.partner + "&_input_charset" + AlipayConfig.input_charset;
/* 200 */     StringBuffer result = new StringBuffer();
/*     */     
/* 202 */     SAXReader reader = new SAXReader();
/* 203 */     Document doc = reader.read(new URL(strUrl).openStream());
/*     */     
/* 205 */     List<Node> nodeList = doc.selectNodes("//alipay/*");
/*     */     Iterator localIterator2;
/* 207 */     label188: for (Iterator localIterator1 = nodeList.iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 212 */         localIterator2.hasNext())
/*     */     {
/* 207 */       Node node = (Node)localIterator1.next();
/*     */       
/* 209 */       if ((!node.getName().equals("is_success")) || (!node.getText().equals("T")))
/*     */         break label188;
/* 211 */       List<Node> nodeList1 = doc.selectNodes("//response/timestamp/*");
/* 212 */       localIterator2 = nodeList1.iterator(); continue;Node node1 = (Node)localIterator2.next();
/* 213 */       result.append(node1.getText());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 218 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\alipay-api.jar!\com\alipay\util\AlipaySubmit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */