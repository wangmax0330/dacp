package com.alipay.util.httpClient;

public enum HttpResultType
{
  STRING,  BYTES;
}


/* Location:              F:\Temp\新建文件夹\alipay-api.jar!\com\alipay\util\httpClient\HttpResultType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */