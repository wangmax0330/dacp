/*     */ package com.alipay.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.codec.digest.DigestUtils;
/*     */ import org.apache.commons.httpclient.methods.multipart.FilePartSource;
/*     */ import org.apache.commons.httpclient.methods.multipart.PartSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AlipayCore
/*     */ {
/*     */   public static Map<String, String> paraFilter(Map<String, String> sArray)
/*     */   {
/*  37 */     Map<String, String> result = new HashMap();
/*     */     
/*  39 */     if ((sArray == null) || (sArray.size() <= 0)) {
/*  40 */       return result;
/*     */     }
/*     */     
/*  43 */     for (String key : sArray.keySet()) {
/*  44 */       String value = (String)sArray.get(key);
/*  45 */       if ((value != null) && (!value.equals("")) && (!key.equalsIgnoreCase("sign")) && 
/*  46 */         (!key.equalsIgnoreCase("sign_type")))
/*     */       {
/*     */ 
/*  49 */         result.put(key, value);
/*     */       }
/*     */     }
/*  52 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createLinkString(Map<String, String> params)
/*     */   {
/*  62 */     List<String> keys = new ArrayList(params.keySet());
/*  63 */     Collections.sort(keys);
/*     */     
/*  65 */     String prestr = "";
/*     */     
/*  67 */     for (int i = 0; i < keys.size(); i++) {
/*  68 */       String key = (String)keys.get(i);
/*  69 */       String value = (String)params.get(key);
/*     */       
/*  71 */       if (i == keys.size() - 1) {
/*  72 */         prestr = prestr + key + "=" + value;
/*     */       } else {
/*  74 */         prestr = prestr + key + "=" + value + "&";
/*     */       }
/*     */     }
/*     */     
/*  78 */     return prestr;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void logResult(String sWord)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_1
/*     */     //   2: new 129	java/io/FileWriter
/*     */     //   5: dup
/*     */     //   6: new 100	java/lang/StringBuilder
/*     */     //   9: dup
/*     */     //   10: getstatic 131	com/alipay/config/AlipayConfig:log_path	Ljava/lang/String;
/*     */     //   13: invokestatic 102	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   16: invokespecial 106	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   19: ldc -120
/*     */     //   21: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   24: invokestatic 138	java/lang/System:currentTimeMillis	()J
/*     */     //   27: invokevirtual 144	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
/*     */     //   30: ldc -109
/*     */     //   32: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   35: invokevirtual 115	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   38: invokespecial 149	java/io/FileWriter:<init>	(Ljava/lang/String;)V
/*     */     //   41: astore_1
/*     */     //   42: aload_1
/*     */     //   43: aload_0
/*     */     //   44: invokevirtual 150	java/io/FileWriter:write	(Ljava/lang/String;)V
/*     */     //   47: goto +50 -> 97
/*     */     //   50: astore_2
/*     */     //   51: aload_2
/*     */     //   52: invokevirtual 153	java/lang/Exception:printStackTrace	()V
/*     */     //   55: aload_1
/*     */     //   56: ifnull +59 -> 115
/*     */     //   59: aload_1
/*     */     //   60: invokevirtual 158	java/io/FileWriter:close	()V
/*     */     //   63: goto +52 -> 115
/*     */     //   66: astore 4
/*     */     //   68: aload 4
/*     */     //   70: invokevirtual 161	java/io/IOException:printStackTrace	()V
/*     */     //   73: goto +42 -> 115
/*     */     //   76: astore_3
/*     */     //   77: aload_1
/*     */     //   78: ifnull +17 -> 95
/*     */     //   81: aload_1
/*     */     //   82: invokevirtual 158	java/io/FileWriter:close	()V
/*     */     //   85: goto +10 -> 95
/*     */     //   88: astore 4
/*     */     //   90: aload 4
/*     */     //   92: invokevirtual 161	java/io/IOException:printStackTrace	()V
/*     */     //   95: aload_3
/*     */     //   96: athrow
/*     */     //   97: aload_1
/*     */     //   98: ifnull +17 -> 115
/*     */     //   101: aload_1
/*     */     //   102: invokevirtual 158	java/io/FileWriter:close	()V
/*     */     //   105: goto +10 -> 115
/*     */     //   108: astore 4
/*     */     //   110: aload 4
/*     */     //   112: invokevirtual 161	java/io/IOException:printStackTrace	()V
/*     */     //   115: return
/*     */     // Line number table:
/*     */     //   Java source line #86	-> byte code offset #0
/*     */     //   Java source line #88	-> byte code offset #2
/*     */     //   Java source line #89	-> byte code offset #42
/*     */     //   Java source line #90	-> byte code offset #47
/*     */     //   Java source line #91	-> byte code offset #51
/*     */     //   Java source line #93	-> byte code offset #55
/*     */     //   Java source line #95	-> byte code offset #59
/*     */     //   Java source line #96	-> byte code offset #63
/*     */     //   Java source line #97	-> byte code offset #68
/*     */     //   Java source line #92	-> byte code offset #76
/*     */     //   Java source line #93	-> byte code offset #77
/*     */     //   Java source line #95	-> byte code offset #81
/*     */     //   Java source line #96	-> byte code offset #85
/*     */     //   Java source line #97	-> byte code offset #90
/*     */     //   Java source line #100	-> byte code offset #95
/*     */     //   Java source line #93	-> byte code offset #97
/*     */     //   Java source line #95	-> byte code offset #101
/*     */     //   Java source line #96	-> byte code offset #105
/*     */     //   Java source line #97	-> byte code offset #110
/*     */     //   Java source line #101	-> byte code offset #115
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	116	0	sWord	String
/*     */     //   1	101	1	writer	java.io.FileWriter
/*     */     //   50	2	2	e	Exception
/*     */     //   76	20	3	localObject	Object
/*     */     //   66	3	4	e	IOException
/*     */     //   88	3	4	e	IOException
/*     */     //   108	3	4	e	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   2	47	50	java/lang/Exception
/*     */     //   59	63	66	java/io/IOException
/*     */     //   2	55	76	finally
/*     */     //   81	85	88	java/io/IOException
/*     */     //   101	105	108	java/io/IOException
/*     */   }
/*     */   
/*     */   public static String getAbstract(String strFilePath, String file_digest_type)
/*     */     throws IOException
/*     */   {
/* 110 */     PartSource file = new FilePartSource(new File(strFilePath));
/* 111 */     if (file_digest_type.equals("MD5")) {
/* 112 */       return DigestUtils.md5Hex(file.createInputStream());
/*     */     }
/* 114 */     if (file_digest_type.equals("SHA")) {
/* 115 */       return DigestUtils.sha256Hex(file.createInputStream());
/*     */     }
/*     */     
/* 118 */     return "";
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\alipay-api.jar!\com\alipay\util\AlipayCore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */