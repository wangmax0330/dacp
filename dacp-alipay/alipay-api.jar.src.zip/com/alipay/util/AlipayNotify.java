/*     */ package com.alipay.util;
/*     */ 
/*     */ import com.alipay.config.AlipayConfig;
/*     */ import com.alipay.sign.MD5;
/*     */ import com.alipay.sign.RSA;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AlipayNotify
/*     */ {
/*     */   private static final String HTTPS_VERIFY_URL = "https://mapi.alipay.com/gateway.do?service=notify_verify&";
/*     */   
/*     */   public static boolean verifyTrade(Map<String, String> params)
/*     */   {
/*  40 */     return verify(params, AlipayConfig.sign_type_rsa);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean verifyRefund(Map<String, String> params)
/*     */   {
/*  50 */     return verify(params, AlipayConfig.sign_type_md5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean verify(Map<String, String> params, String signType)
/*     */   {
/*  64 */     String responseTxt = "true";
/*  65 */     if (params.get("notify_id") != null) {
/*  66 */       String notify_id = (String)params.get("notify_id");
/*  67 */       responseTxt = verifyResponse(notify_id);
/*     */     }
/*  69 */     String sign = "";
/*  70 */     if (params.get("sign") != null) sign = (String)params.get("sign");
/*  71 */     boolean isSign = getSignVeryfy(params, sign, signType);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     if ((isSign) && (responseTxt.equals("true"))) {
/*  78 */       return true;
/*     */     }
/*  80 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean getSignVeryfy(Map<String, String> Params, String sign, String signType)
/*     */   {
/*  92 */     Map<String, String> sParaNew = AlipayCore.paraFilter(Params);
/*     */     
/*  94 */     String preSignStr = AlipayCore.createLinkString(sParaNew);
/*     */     
/*  96 */     boolean isSign = false;
/*  97 */     if (AlipayConfig.sign_type_md5.equals(signType)) {
/*  98 */       isSign = MD5.verify(preSignStr, sign, AlipayConfig.private_key, AlipayConfig.input_charset);
/*  99 */     } else if (AlipayConfig.sign_type_rsa.equals(signType)) {
/* 100 */       isSign = RSA.verify(preSignStr, sign, AlipayConfig.ali_public_key_rsa, AlipayConfig.input_charset);
/*     */     }
/* 102 */     return isSign;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String verifyResponse(String notify_id)
/*     */   {
/* 117 */     String partner = AlipayConfig.partner;
/* 118 */     String veryfy_url = "https://mapi.alipay.com/gateway.do?service=notify_verify&partner=" + partner + "&notify_id=" + notify_id;
/*     */     
/* 120 */     return checkUrl(veryfy_url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String checkUrl(String urlvalue)
/*     */   {
/* 133 */     String inputLine = "";
/*     */     try
/*     */     {
/* 136 */       URL url = new URL(urlvalue);
/* 137 */       HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
/* 138 */       BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection
/* 139 */         .getInputStream()));
/* 140 */       inputLine = in.readLine().toString();
/*     */     } catch (Exception e) {
/* 142 */       e.printStackTrace();
/* 143 */       inputLine = "";
/*     */     }
/*     */     
/* 146 */     return inputLine;
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\alipay-api.jar!\com\alipay\util\AlipayNotify.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */