/*    */ package com.alipay.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlipayConfig
/*    */ {
/* 28 */   public static String partner = "2088411586220692";
/*    */   
/* 30 */   public static String private_key = "gs28tzm2h0sk117apc2bbrav6jjtc5j7";
/*    */   
/*    */ 
/* 33 */   public static String private_key_rsa = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAPGMpVl9n5MpEwyJXqgLY5JouucETNwV8y0Pq8MLAA7oD6FOSPzjlJaH3pI31VqazWZBtLhKXBTrvylj9fnquIhzdOsCklN2OFgOqmdV3m8PmsiFqwfqKE6T7qsl2TPpCMiF3HPeE555fcJwWW4HGWcdrElEjfhoRzQfr4jC0R0FAgMBAAECgYEAmeKYlOLLft10HVCG1VgsH2JJcFP1A2GYguSw8JlZeCWvj3xoU3RJfX0h9tVLP2XP5Y2GrMHy2AE40A2273jyBf9rDhsLQmCymZirRQP81LR5El4TOcu5S/zW5hNCmEBrT9OgPPLVIr7V26QPGCfnP9WW5OePkinE/RGxo8kR9QECQQD7OnvN5SU5nU9MmD1I6MNmuUyhT6w3DN0P7DqXHWHj1FIKpR7mJQQg7yRXfDBGEtIy9ROQ72hWmixjpOANaBYJAkEA9iMZ3iQlezbCQEAwVXJOZ5tY7GqEE1POL3ncwIRSUhiNDTFxNA5zxF5ifN0Rd3O5FlSNRKMpvUNt6r8ilckuHQJANbeakzrEy93r/8epivZiGYvTa8Z6X0b72ZS8LmWU8b8LT8VgpvsRN+2KSr5+H+2UTlsCtQHLwIC0rxWo5pTz6QJAUEcsha5mZyR6ALiuyv+oINSjESDAiQk5Y3SskkHWE56cSqRIlsDr8y0RlEYKD1q4EFdtZ+iLkYYvkHPclNvz5QJBAM+v5lUUbNQ4yPwvQZrT8p7uXSIbVw1SkkspnsBDTCPTydOEs1MUr7OH8gkKuup6H4jrxX8FhfdARWbZyLzrFsI=";
/*    */   
/*    */ 
/* 36 */   public static String ali_public_key_rsa = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 41 */   public static String log_path = "../logs/";
/*    */   
/*    */ 
/* 44 */   public static String input_charset = "utf-8";
/*    */   
/*    */ 
/* 47 */   public static String sign_type_rsa = "RSA";
/*    */   
/* 49 */   public static String sign_type_md5 = "MD5";
/*    */ }


/* Location:              F:\Temp\新建文件夹\alipay-api.jar!\com\alipay\config\AlipayConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */