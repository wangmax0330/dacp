/*     */ package com.unionpay.acp.sdksample.front;
/*     */ 
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import com.unionpay.acp.sdksample.back.Common;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrontPay
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  22 */     String encoding = "UTF-8";
/*     */     
/*     */ 
/*     */ 
/*  26 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  28 */     String requestUrl = SDKConfig.getConfig().getFrontRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*  32 */     Map<String, String> data = new HashMap();
/*     */     
/*  34 */     data.put("version", "5.0.0");
/*     */     
/*  36 */     data.put("encoding", encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */     data.put("signMethod", "01");
/*     */     
/*  44 */     data.put("txnType", "01");
/*     */     
/*  46 */     data.put("txnSubType", "01");
/*     */     
/*  48 */     data.put("bizType", "000000");
/*     */     
/*  50 */     data.put("channelType", "08");
/*     */     
/*  52 */     data.put("frontUrl", "http://localhost:8080/ACPTest/acp_front_url.do");
/*     */     
/*  54 */     data.put("backUrl", "http://localhost:8080/ACPTest/acp_back_url.do");
/*     */     
/*  56 */     data.put("accessType", "0");
/*     */     
/*  58 */     data.put("acqInsCode", "");
/*     */     
/*  60 */     data.put("merCatCode", "");
/*     */     
/*  62 */     data.put("merId", "105550149170027");
/*     */     
/*  64 */     data.put("merName", "");
/*     */     
/*  66 */     data.put("merAbbr", "");
/*     */     
/*  68 */     data.put("subMerId", "");
/*     */     
/*  70 */     data.put("subMerName", "");
/*     */     
/*  72 */     data.put("subMerAbbr", "");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */     data.put("accType", "");
/*     */     
/*  80 */     data.put("accNo", "");
/*     */     
/*     */ 
/*     */ 
/*  84 */     data.put("txnAmt", "1");
/*     */     
/*  86 */     data.put("currencyCode", "156");
/*     */     
/*  88 */     data.put("customerInfo", Common.getCustomer(encoding));
/*     */     
/*  90 */     data.put("orderTimeout", "12");
/*     */     
/*  92 */     data.put("payTimeout", "20120815135900");
/*     */     
/*  94 */     data.put("termId", "");
/*     */     
/*  96 */     data.put("reqReserved", "");
/*     */     
/*  98 */     data.put("reserved", "");
/*     */     
/* 100 */     data.put("riskRateInfo", "");
/*     */     
/* 102 */     data.put("encryptCertId", "");
/*     */     
/* 104 */     data.put("frontFailUrl", "");
/*     */     
/* 106 */     data.put("instalTransInfo", "");
/*     */     
/* 108 */     data.put("defaultPayType", "");
/*     */     
/* 110 */     data.put("issInsCode", "");
/*     */     
/* 112 */     data.put("supPayType", "");
/*     */     
/* 114 */     data.put("userMac", "");
/*     */     
/* 116 */     data.put("customerIp", "127.0.0.1");
/*     */     
/* 118 */     data.put("bindId", "");
/*     */     
/* 120 */     data.put("payCardType", "");
/*     */     
/* 122 */     data.put("securityType", "");
/*     */     
/* 124 */     data.put("cardTransData", "");
/*     */     
/* 126 */     data.put("vpcTransData", "");
/*     */     
/* 128 */     data.put("orderDesc", "");
/*     */     
/*     */ 
/* 131 */     Map<String, String> request = new HashMap();
/* 132 */     request.putAll(data);
/* 133 */     Set<String> set = data.keySet();
/* 134 */     Iterator<String> iterator = set.iterator();
/* 135 */     while (iterator.hasNext()) {
/* 136 */       String key = (String)iterator.next();
/* 137 */       if ((null == data.get(key)) || ("".equals(data.get(key)))) {
/* 138 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 145 */     SDKUtil.sign(request, encoding);
/*     */     
/*     */ 
/*     */ 
/* 149 */     String html = createHtml(requestUrl, request);
/* 150 */     System.out.println(html);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createHtml(String action, Map<String, String> hiddens)
/*     */   {
/* 163 */     StringBuffer sf = new StringBuffer();
/* 164 */     sf.append("<form id = \"sform\" action=\"" + action + "\" method=\"post\">");
/*     */     
/* 166 */     if ((null != hiddens) && (0 != hiddens.size())) {
/* 167 */       Set<Map.Entry<String, String>> set = hiddens.entrySet();
/* 168 */       Iterator<Map.Entry<String, String>> it = set.iterator();
/* 169 */       while (it.hasNext()) {
/* 170 */         Map.Entry<String, String> ey = (Map.Entry)it.next();
/* 171 */         String key = (String)ey.getKey();
/* 172 */         String value = (String)ey.getValue();
/* 173 */         sf.append("<input type=\"hidden\" name=\"" + key + "\" id=\"" + key + "\" value=\"" + value + "\"/>");
/*     */       }
/*     */     }
/*     */     
/* 177 */     sf.append("</form>");
/* 178 */     sf.append("</body>");
/* 179 */     sf.append("<script type=\"text/javascript\">");
/* 180 */     sf.append("document.all.sform.submit();");
/* 181 */     sf.append("</script>");
/* 182 */     return sf.toString();
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\front\FrontPay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */