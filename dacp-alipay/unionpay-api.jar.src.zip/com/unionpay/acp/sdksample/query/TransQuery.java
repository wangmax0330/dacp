/*     */ package com.unionpay.acp.sdksample.query;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransQuery
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  21 */     String encoding = "UTF-8";
/*     */     
/*  23 */     String result = "";
/*     */     
/*     */ 
/*     */ 
/*  27 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  29 */     String requestUrl = SDKConfig.getConfig().getBackRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*  33 */     Map<String, String> data = new HashMap();
/*     */     
/*  35 */     data.put("version", "5.0.0");
/*     */     
/*  37 */     data.put("encoding", encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  43 */     data.put("signMethod", "01");
/*     */     
/*  45 */     data.put("txnType", "01");
/*     */     
/*  47 */     data.put("txnSubType", "01");
/*     */     
/*  49 */     data.put("bizType", "000000");
/*     */     
/*  51 */     data.put("acqInsCode", "");
/*     */     
/*  53 */     data.put("accessType", "0");
/*     */     
/*  55 */     data.put("merId", "210440383989420");
/*     */     
/*  57 */     data.put("txnTime", "20140715052503");
/*     */     
/*  59 */     data.put("orderId", "20140712152503abcde");
/*     */     
/*  61 */     data.put("queryId", "");
/*     */     
/*  63 */     data.put("reserved", "");
/*     */     
/*     */ 
/*  66 */     Map<String, String> request = new HashMap();
/*  67 */     request.putAll(data);
/*  68 */     Set<String> set = data.keySet();
/*  69 */     Iterator<String> iterator = set.iterator();
/*  70 */     while (iterator.hasNext()) {
/*  71 */       String key = (String)iterator.next();
/*  72 */       if ((null == data.get(key)) || ("".equals(data.get(key)))) {
/*  73 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  80 */     SDKUtil.sign(request, encoding);
/*     */     
/*     */ 
/*     */ 
/*  84 */     HttpClient hc = new HttpClient(requestUrl, 30000, 30000);
/*     */     try {
/*  86 */       int status = hc.send(request, encoding);
/*  87 */       if (200 == status) {
/*  88 */         result = hc.getResult();
/*     */       }
/*     */     } catch (Exception e) {
/*  91 */       e.printStackTrace();
/*     */     }
/*     */     
/*  94 */     System.out.println("报文发送后的响应信息：  " + result);
/*     */     
/*     */ 
/*     */ 
/*  98 */     if ((null != result) && (!"".equals(result)))
/*     */     {
/* 100 */       Map<String, String> resData = SDKUtil.convertResultStringToMap(result);
/*     */       
/* 102 */       if (SDKUtil.validate(resData, encoding)) {
/* 103 */         System.out.println("验证签名成功");
/*     */       } else {
/* 105 */         System.out.println("验证签名失败");
/*     */       }
/*     */       
/* 108 */       System.out.println(result);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\query\TransQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */