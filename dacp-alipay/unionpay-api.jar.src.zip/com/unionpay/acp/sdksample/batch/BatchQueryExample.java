/*     */ package com.unionpay.acp.sdksample.batch;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.LogUtil;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import com.unionpay.acp.sdk.SecureUtil;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchQueryExample
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  30 */     String fileName = "TH00000000700000000000001201407101000I.txt";
/*  31 */     send(fileName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fieldUpload(Map<String, String> map, String fileName)
/*     */   {
/*     */     try
/*     */     {
/*  45 */       URL dd = BatchQueryExample.class.getClassLoader().getResource(fileName);
/*     */       
/*     */ 
/*  48 */       FileInputStream ins = new FileInputStream(dd.getFile());
/*  49 */       byte[] b = new byte[ins.available()];
/*  50 */       ins.read(b);
/*  51 */       ins.close();
/*  52 */       String string = new String(b);
/*  53 */       string = new String(SecureUtil.base64Encode(SecureUtil.deflater(b)));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  58 */       System.out.println(string);
/*  59 */       map.put("fileContent", string);
/*     */     }
/*     */     catch (Exception e) {
/*  62 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void send(String fileName)
/*     */   {
/*  70 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  72 */     String type = fileName.substring(0, 2);
/*  73 */     String acqInsCode = fileName.substring(2, 10);
/*  74 */     String merId = fileName.substring(10, 25);
/*  75 */     String txnTime = fileName.substring(25, 33);
/*  76 */     String batchNo = fileName.substring(33, 37);
/*     */     
/*  78 */     String version = "5.0.0";
/*  79 */     String encoding = "UTF-8";
/*  80 */     String certId = "999999999999";
/*     */     
/*  82 */     String signMethod = "02";
/*  83 */     String txnType = "22";
/*     */     
/*  85 */     String txnSubType = "01";
/*  86 */     if ("TH".equals(type)) {
/*  87 */       txnSubType = "01";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*  93 */     else if ("DK".equals(type)) {
/*  94 */       txnSubType = "02";
/*     */     }
/*  96 */     else if ("DF".equals(type)) {
/*  97 */       txnSubType = "03";
/*     */     }
/*  99 */     String bizType = "000000";
/* 100 */     String channelType = "08";
/* 101 */     String accessType = "0";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 106 */     String reqReserved = "";
/* 107 */     String reserved = "";
/*     */     
/* 109 */     Map<String, String> req = new HashMap();
/*     */     
/* 111 */     req.put("version", version);
/* 112 */     req.put("encoding", encoding);
/* 113 */     req.put("certId", certId);
/*     */     
/* 115 */     req.put("signMethod", signMethod);
/* 116 */     req.put("txnType", txnType);
/* 117 */     req.put("txnSubType", txnSubType);
/* 118 */     req.put("bizType", bizType);
/* 119 */     req.put("channelType", channelType);
/* 120 */     req.put("accessType", accessType);
/* 121 */     if (StringUtils.isNotBlank(acqInsCode)) {
/* 122 */       req.put("acqInsCode", acqInsCode);
/*     */     }
/* 124 */     if (StringUtils.isNotBlank(merId)) {
/* 125 */       req.put("merId", merId);
/*     */     }
/* 127 */     req.put("batchNo", batchNo);
/* 128 */     SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
/* 129 */     req.put("txnTime", txnTime + sdf.format(new Date()));
/* 130 */     if (StringUtils.isNotBlank(reqReserved)) {
/* 131 */       req.put("reqReserved", reqReserved);
/*     */     }
/* 133 */     if (StringUtils.isNotBlank(reserved)) {
/* 134 */       req.put("reserved", reserved);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 140 */     SDKUtil.sign(req, encoding);
/*     */     
/* 142 */     LogUtil.writeLog("BackRequest组装请求报文表单如下");
/* 143 */     LogUtil.printRequestLog(req);
/*     */     
/*     */ 
/* 146 */     String queryUrl = SDKConfig.getConfig().getBatchQueryUrl();
/*     */     
/* 148 */     LogUtil.writeLog("发送报文到后台");
/* 149 */     LogUtil.writeLog("请求地址queryUrl=[" + queryUrl + "]");
/* 150 */     String result = null;
/*     */     
/*     */ 
/*     */ 
/* 154 */     HttpClient hc = new HttpClient(queryUrl, 30000, 30000);
/*     */     try {
/* 156 */       int status = hc.send(req, encoding);
/* 157 */       if (200 == status) {
/* 158 */         result = hc.getResult();
/*     */       }
/*     */     } catch (Exception e) {
/* 161 */       e.printStackTrace();
/*     */     }
/*     */     
/* 164 */     System.out.println("报文发送后的响应信息：  " + result);
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\batch\BatchQueryExample.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */