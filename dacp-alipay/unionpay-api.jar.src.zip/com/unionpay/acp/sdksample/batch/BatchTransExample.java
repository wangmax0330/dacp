/*     */ package com.unionpay.acp.sdksample.batch;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.LogUtil;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import com.unionpay.acp.sdk.SecureUtil;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchTransExample
/*     */ {
/*  30 */   public static String FILENAME = "TH00000000700000000000001201407101000I.txt";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String acqInsCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String merId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String txnTime;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String batchNo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String totalQty;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String totalAmt;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void decode() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fieldUpload(Map<String, String> map, String fileName)
/*     */   {
/*     */     try
/*     */     {
/*  98 */       URL dd = BatchTransExample.class.getClassLoader().getResource(fileName);
/*     */       
/*     */ 
/* 101 */       if (null == dd) {
/* 102 */         LogUtil.writeLog("找不到文件" + fileName);
/* 103 */         return;
/*     */       }
/* 105 */       FileInputStream ins = new FileInputStream(dd.getFile());
/* 106 */       byte[] b = new byte[ins.available()];
/* 107 */       ins.read(b);
/* 108 */       ins.close();
/* 109 */       FileReader fr = new FileReader(dd.getFile());
/*     */       
/*     */ 
/* 112 */       BufferedReader br = new BufferedReader(fr);
/* 113 */       String ss = br.readLine();
/* 114 */       br.close();
/*     */       
/* 116 */       String[] arr = ss.split("[|]");
/* 117 */       type = fileName.substring(0, 2);
/* 118 */       acqInsCode = fileName.substring(2, 10);
/* 119 */       merId = fileName.substring(10, 25);
/* 120 */       txnTime = fileName.substring(25, 33);
/* 121 */       batchNo = fileName.substring(33, 37);
/*     */       
/* 123 */       merId = arr[0];
/* 124 */       batchNo = arr[1];
/* 125 */       txnTime = arr[2];
/* 126 */       totalAmt = arr[3];
/* 127 */       totalQty = arr[4];
/*     */       
/* 129 */       String string = new String(b);
/* 130 */       string = new String(SecureUtil.base64Encode(SecureUtil.deflater(b)));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 135 */       map.put("fileContent", string);
/* 136 */       String txnSubType = null;
/* 137 */       if ("TH".equals(type)) {
/* 138 */         txnSubType = "01";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 144 */       else if ("DK".equals(type)) {
/* 145 */         txnSubType = "02";
/*     */       }
/* 147 */       else if ("DF".equals(type)) {
/* 148 */         txnSubType = "03";
/*     */       }
/*     */       
/*     */ 
/* 152 */       map.put("txnSubType", txnSubType);
/*     */     } catch (Exception e) {
/* 154 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void send()
/*     */   {
/* 162 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/* 164 */     String version = "5.0.0";
/* 165 */     String encoding = "UTF-8";
/* 166 */     String certId = "999999999999";
/*     */     
/* 168 */     String signMethod = "02";
/* 169 */     String txnType = "21";
/*     */     
/*     */ 
/* 172 */     String bizType = "000000";
/* 173 */     String channelType = "08";
/* 174 */     String accessType = "1";
/*     */     
/*     */ 
/* 177 */     String subMerId = "";
/* 178 */     String subMerName = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */     String reqReserved = "";
/* 185 */     String reserved = "";
/*     */     
/* 187 */     Map<String, String> req = new HashMap();
/* 188 */     fieldUpload(req, FILENAME);
/* 189 */     req.put("version", version);
/* 190 */     req.put("encoding", encoding);
/* 191 */     req.put("certId", certId);
/*     */     
/* 193 */     req.put("signMethod", signMethod);
/* 194 */     req.put("txnType", txnType);
/*     */     
/* 196 */     req.put("bizType", bizType);
/* 197 */     req.put("channelType", channelType);
/* 198 */     req.put("accessType", accessType);
/* 199 */     if (StringUtils.isNotBlank(acqInsCode)) {
/* 200 */       req.put("acqInsCode", acqInsCode);
/*     */     }
/* 202 */     if (StringUtils.isNotBlank(merId)) {
/* 203 */       req.put("merId", merId);
/*     */     }
/* 205 */     if (StringUtils.isNotBlank(subMerId)) {
/* 206 */       req.put("subMerId", subMerId);
/*     */     }
/* 208 */     if (StringUtils.isNotBlank(subMerName)) {
/* 209 */       req.put("subMerName", subMerName);
/*     */     }
/* 211 */     req.put("batchNo", batchNo);
/* 212 */     SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
/* 213 */     req.put("txnTime", txnTime + sdf.format(new Date()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 218 */     req.put("totalQty", totalQty);
/*     */     
/* 220 */     req.put("totalAmt", totalAmt);
/*     */     
/* 222 */     if (StringUtils.isNotBlank(reqReserved)) {
/* 223 */       req.put("reqReserved", reqReserved);
/*     */     }
/* 225 */     if (StringUtils.isNotBlank(reserved)) {
/* 226 */       req.put("reserved", reserved);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 232 */     SDKUtil.sign(req, encoding);
/*     */     
/* 234 */     LogUtil.writeLog("BackRequest组装请求报文表单如下");
/* 235 */     LogUtil.printRequestLog(req);
/*     */     
/*     */ 
/* 238 */     String tradUrl = SDKConfig.getConfig().getBatchTransUrl();
/*     */     
/* 240 */     LogUtil.writeLog("发送报文到后台");
/* 241 */     LogUtil.writeLog("请求地址tradUrl=[" + tradUrl + "]");
/* 242 */     String result = null;
/*     */     
/*     */ 
/*     */ 
/* 246 */     HttpClient hc = new HttpClient(tradUrl, 30000, 30000);
/*     */     try {
/* 248 */       int status = hc.send(req, encoding);
/* 249 */       if (200 == status) {
/* 250 */         result = hc.getResult();
/*     */       }
/*     */     } catch (Exception e) {
/* 253 */       e.printStackTrace();
/*     */     }
/*     */     
/* 256 */     System.out.println("报文发送后的响应信息：  " + result);
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\batch\BatchTransExample.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */