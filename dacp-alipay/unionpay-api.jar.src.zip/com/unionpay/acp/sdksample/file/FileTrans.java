/*     */ package com.unionpay.acp.sdksample.file;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import com.unionpay.acp.sdk.SecureUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileTrans
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  29 */     String encoding = "UTF-8";
/*     */     
/*  31 */     String result = "";
/*     */     
/*     */ 
/*     */ 
/*  35 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  37 */     String requestUrl = SDKConfig.getConfig().getFileTransUrl();
/*  38 */     System.out.println("文件请求地址=[" + requestUrl + "]");
/*     */     
/*     */ 
/*     */ 
/*  42 */     Map<String, String> data = new HashMap();
/*     */     
/*  44 */     data.put("version", "5.0.0");
/*     */     
/*  46 */     data.put("encoding", encoding);
/*     */     
/*     */ 
/*  49 */     data.put("signMethod", "01");
/*     */     
/*  51 */     data.put("txnType", "76");
/*     */     
/*  53 */     data.put("txnSubType", "01");
/*     */     
/*  55 */     data.put("bizType", "000000");
/*     */     
/*     */ 
/*  58 */     data.put("channelType", "07");
/*     */     
/*  60 */     data.put("accessType", "0");
/*     */     
/*  62 */     data.put("merId", "700000000000001");
/*     */     
/*     */ 
/*     */ 
/*  66 */     data.put("subMerId", "");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */     data.put("settleDate", "0502");
/*     */     
/*  74 */     data.put("txnTime", SDKUtil.generateTxnTime());
/*     */     
/*  76 */     data.put("fileType", "00");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     Map<String, String> request = new HashMap();
/*  84 */     request.putAll(data);
/*  85 */     Set<String> set = data.keySet();
/*  86 */     Iterator<String> iterator = set.iterator();
/*  87 */     while (iterator.hasNext()) {
/*  88 */       String key = (String)iterator.next();
/*  89 */       if ((null == data.get(key)) || ("".equals(data.get(key)))) {
/*  90 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  97 */     SDKUtil.sign(request, encoding);
/*     */     
/*     */ 
/*     */ 
/* 101 */     HttpClient hc = new HttpClient(requestUrl, 160000, 280000);
/*     */     try {
/* 103 */       int status = hc.send(request, encoding);
/* 104 */       if (200 == status) {
/* 105 */         result = hc.getResult();
/*     */       }
/*     */     } catch (Exception e) {
/* 108 */       e.printStackTrace();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 114 */     System.out.println("返回报文=[" + result + "]");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     if ((null != result) && (!"".equals(result)))
/*     */     {
/* 121 */       Map<String, String> resData = SDKUtil.convertResultStringToMap(result);
/*     */       
/* 123 */       if (SDKUtil.validate(resData, encoding)) {
/* 124 */         System.out.println("验证签名成功");
/*     */         
/*     */ 
/* 127 */         String fileContent = (String)resData.get("fileContent");
/*     */         
/* 129 */         if ((null != fileContent) && (!"".equals(fileContent))) {
/*     */           try {
/* 131 */             byte[] fileArray = SecureUtil.inflater(SecureUtil.base64Decode(fileContent.getBytes(encoding)));
/*     */             
/* 133 */             String root = "D:\\";
/* 134 */             String filePath = null;
/* 135 */             if (SDKUtil.isEmpty((String)resData.get("fileName"))) {
/* 136 */               filePath = root + File.separator + (String)resData.get("merId") + "_" + (String)resData.get("batchNo") + "_" + (String)resData.get("txnTime") + ".txt";
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/* 141 */               filePath = root + File.separator + (String)resData.get("fileName");
/*     */             }
/*     */             
/* 144 */             File file = new File(filePath);
/* 145 */             if (file.exists()) {
/* 146 */               file.delete();
/*     */             }
/* 148 */             file.createNewFile();
/* 149 */             FileOutputStream out = new FileOutputStream(file);
/* 150 */             out.write(fileArray, 0, fileArray.length);
/* 151 */             out.flush();
/* 152 */             out.close();
/*     */           }
/*     */           catch (UnsupportedEncodingException e) {
/* 155 */             e.printStackTrace();
/*     */           } catch (IOException e) {
/* 157 */             e.printStackTrace();
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 163 */         System.out.println("验证签名失败");
/*     */       }
/*     */       
/* 166 */       System.out.println(result);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\file\FileTrans.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */