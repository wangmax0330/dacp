/*     */ package com.unionpay.acp.sdksample.notice;
/*     */ 
/*     */ import com.unionpay.acp.sdk.LogUtil;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrontRcvResponse
/*     */   extends HttpServlet
/*     */ {
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/*  32 */     LogUtil.writeLog("FrontRcvResponse前台接收报文返回开始");
/*     */     
/*  34 */     req.setCharacterEncoding("ISO-8859-1");
/*  35 */     String encoding = req.getParameter("encoding");
/*  36 */     LogUtil.writeLog("返回报文中encoding=[" + encoding + "]");
/*  37 */     String pageResult = "";
/*  38 */     if ("UTF-8".equalsIgnoreCase(encoding)) {
/*  39 */       pageResult = "/utf8_result.jsp";
/*     */     } else {
/*  41 */       pageResult = "/gbk_result.jsp";
/*     */     }
/*  43 */     Map<String, String> respParam = getAllRequestParam(req);
/*     */     
/*     */ 
/*  46 */     LogUtil.printRequestLog(respParam);
/*     */     
/*  48 */     Map<String, String> valideData = null;
/*  49 */     StringBuffer page = new StringBuffer();
/*  50 */     if ((null != respParam) && (!respParam.isEmpty())) {
/*  51 */       Iterator<Map.Entry<String, String>> it = respParam.entrySet().iterator();
/*     */       
/*  53 */       valideData = new HashMap(respParam.size());
/*  54 */       while (it.hasNext()) {
/*  55 */         Map.Entry<String, String> e = (Map.Entry)it.next();
/*  56 */         String key = (String)e.getKey();
/*  57 */         String value = (String)e.getValue();
/*  58 */         value = new String(value.getBytes("ISO-8859-1"), encoding);
/*  59 */         page.append("<tr><td width=\"30%\" align=\"right\">" + key + "(" + key + ")</td><td>" + value + "</td></tr>");
/*     */         
/*  61 */         valideData.put(key, value);
/*     */       }
/*     */     }
/*  64 */     if (!SDKUtil.validate(valideData, encoding)) {
/*  65 */       page.append("<tr><td width=\"30%\" align=\"right\">验证签名结果</td><td>失败</td></tr>");
/*  66 */       LogUtil.writeLog("验证签名结果[失败].");
/*     */     } else {
/*  68 */       page.append("<tr><td width=\"30%\" align=\"right\">验证签名结果</td><td>成功</td></tr>");
/*  69 */       LogUtil.writeLog("验证签名结果[成功].");
/*     */     }
/*  71 */     req.setAttribute("result", page.toString());
/*  72 */     req.getRequestDispatcher(pageResult).forward(req, resp);
/*     */     
/*  74 */     LogUtil.writeLog("FrontRcvResponse前台接收报文返回结束");
/*     */   }
/*     */   
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/*  80 */     doPost(req, resp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> getAllRequestParam(HttpServletRequest request)
/*     */   {
/*  91 */     Map<String, String> res = new HashMap();
/*  92 */     Enumeration<?> temp = request.getParameterNames();
/*  93 */     if (null != temp) {
/*  94 */       while (temp.hasMoreElements()) {
/*  95 */         String en = (String)temp.nextElement();
/*  96 */         String value = request.getParameter(en);
/*  97 */         res.put(en, value);
/*     */         
/*  99 */         if ((res.get(en) == null) || ("".equals(res.get(en))))
/*     */         {
/* 101 */           res.remove(en);
/*     */         }
/*     */       }
/*     */     }
/* 105 */     return res;
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\notice\FrontRcvResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */