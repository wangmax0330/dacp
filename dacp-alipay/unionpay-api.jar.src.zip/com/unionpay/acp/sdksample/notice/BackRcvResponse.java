/*     */ package com.unionpay.acp.sdksample.notice;
/*     */ 
/*     */ import com.unionpay.acp.sdk.LogUtil;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BackRcvResponse
/*     */   extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 3414800502432002480L;
/*     */   
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/*  42 */     LogUtil.writeLog("BackRcvResponse接收后台通知开始");
/*     */     
/*  44 */     req.setCharacterEncoding("ISO-8859-1");
/*  45 */     String encoding = req.getParameter("encoding");
/*     */     
/*  47 */     Map<String, String> reqParam = getAllRequestParam(req);
/*     */     
/*  49 */     LogUtil.printRequestLog(reqParam);
/*     */     
/*  51 */     Map<String, String> valideData = null;
/*  52 */     if ((null != reqParam) && (!reqParam.isEmpty())) {
/*  53 */       Iterator<Map.Entry<String, String>> it = reqParam.entrySet().iterator();
/*  54 */       valideData = new HashMap(reqParam.size());
/*  55 */       while (it.hasNext()) {
/*  56 */         Map.Entry<String, String> e = (Map.Entry)it.next();
/*  57 */         String key = (String)e.getKey();
/*  58 */         String value = (String)e.getValue();
/*  59 */         value = new String(value.getBytes("ISO-8859-1"), encoding);
/*  60 */         valideData.put(key, value);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  65 */     if (!SDKUtil.validate(valideData, encoding)) {
/*  66 */       LogUtil.writeLog("验证签名结果[失败].");
/*     */     } else {
/*  68 */       LogUtil.writeLog("验证签名结果[成功].");
/*     */     }
/*     */     
/*  71 */     LogUtil.writeLog("BackRcvResponse接收后台通知结束");
/*     */   }
/*     */   
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/*  77 */     doPost(req, resp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> getAllRequestParam(HttpServletRequest request)
/*     */   {
/*  87 */     Map<String, String> res = new HashMap();
/*  88 */     Enumeration<?> temp = request.getParameterNames();
/*  89 */     if (null != temp) {
/*  90 */       while (temp.hasMoreElements()) {
/*  91 */         String en = (String)temp.nextElement();
/*  92 */         String value = request.getParameter(en);
/*  93 */         res.put(en, value);
/*     */         
/*     */ 
/*  96 */         if ((null == res.get(en)) || ("".equals(res.get(en)))) {
/*  97 */           res.remove(en);
/*     */         }
/*     */       }
/*     */     }
/* 101 */     return res;
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\notice\BackRcvResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */