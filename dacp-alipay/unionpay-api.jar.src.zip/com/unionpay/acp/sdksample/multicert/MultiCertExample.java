/*     */ package com.unionpay.acp.sdksample.multicert;
/*     */ 
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiCertExample
/*     */   extends DemoBase
/*     */ {
/*     */   public static Map<String, Object> setFormDate()
/*     */   {
/*  36 */     Map<String, Object> contentData = new HashMap();
/*     */     
/*     */ 
/*  39 */     contentData.put("version", "5.0.0");
/*     */     
/*  41 */     contentData.put("encoding", "UTF-8");
/*     */     
/*  43 */     contentData.put("signMethod", "01");
/*     */     
/*  45 */     contentData.put("txnType", "01");
/*     */     
/*  47 */     contentData.put("txnSubType", "01");
/*     */     
/*  49 */     contentData.put("bizType", "000201");
/*     */     
/*  51 */     contentData.put("channelType", "07");
/*     */     
/*  53 */     contentData.put("backUrl", backUrl);
/*     */     
/*  55 */     contentData.put("accessType", "0");
/*     */     
/*  57 */     contentData.put("merId", "802290049000180");
/*     */     
/*  59 */     contentData.put("subMerId", "");
/*     */     
/*  61 */     contentData.put("subMerName", "");
/*     */     
/*  63 */     contentData.put("subMerAbbr", "");
/*     */     
/*  65 */     contentData.put("orderId", getOrderId());
/*     */     
/*  67 */     contentData.put("txnTime", getCurrentTime());
/*     */     
/*     */ 
/*  70 */     contentData.put("accType", "");
/*     */     
/*  72 */     contentData.put("accNo", "");
/*     */     
/*  74 */     contentData.put("txnAmt", "1");
/*     */     
/*  76 */     contentData.put("currencyCode", "156");
/*     */     
/*  78 */     contentData.put("customerInfo", getCustomer(encoding));
/*     */     
/*  80 */     contentData.put("orderTimeout", "");
/*     */     
/*  82 */     contentData.put("payTimeout", "");
/*     */     
/*  84 */     contentData.put("termId", "");
/*     */     
/*  86 */     contentData.put("reqReserved", "");
/*  87 */     contentData.put("reserved", "");
/*     */     
/*  89 */     contentData.put("riskRateInfo", "");
/*     */     
/*  91 */     contentData.put("encryptCertId", "");
/*     */     
/*  93 */     contentData.put("instalTransInfo", "");
/*     */     
/*  95 */     contentData.put("defaultPayType", "");
/*     */     
/*  97 */     contentData.put("issInsCode", "");
/*     */     
/*  99 */     contentData.put("supPayType", "");
/*     */     
/* 101 */     contentData.put("userMac", "");
/*     */     
/* 103 */     contentData.put("customerIp", "");
/*     */     
/* 105 */     contentData.put("bindId", "");
/*     */     
/* 107 */     contentData.put("payCardType", "");
/*     */     
/* 109 */     contentData.put("cardTransData", getCardTransData(contentData, encoding));
/*     */     
/*     */ 
/* 112 */     contentData.put("orderDesc", "");
/*     */     
/* 114 */     return contentData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 123 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 128 */     String requestBackUrl = SDKConfig.getConfig().getBackRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 133 */     Map<String, String> resmap1 = submitDate(setFormDate(), requestBackUrl, "d:\\certs\\106660149170027_000000.pfx", "000000");
/*     */     
/* 135 */     System.out.println(resmap1.toString());
/*     */     
/* 137 */     Map<String, String> resmap2 = submitDate(setFormDate(), requestBackUrl, "d:\\certs\\00201000_111111.pfx", "111111");
/*     */     
/* 139 */     System.out.println(resmap2.toString());
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\multicert\MultiCertExample.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */