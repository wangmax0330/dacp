/*     */ package com.unionpay.acp.sdksample.multicert;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import com.unionpay.acp.sdk.SecureUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.httpclient.util.DateUtil;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DemoBase
/*     */ {
/*  33 */   public static String encoding = "UTF-8";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  38 */   public static String version = "5.0.0";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */   public static String frontUrl = "http://localhost:8080/ACPTest/acp_front_url.do";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */   public static String backUrl = "http://localhost:8080/ACPTest/acp_back_url.do";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createHtml(String action, Map<String, String> hiddens)
/*     */   {
/*  66 */     StringBuffer sf = new StringBuffer();
/*  67 */     sf.append("<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"/></head><body>");
/*  68 */     sf.append("<form id = \"pay_form\" action=\"" + action + "\" method=\"post\">");
/*     */     
/*  70 */     if ((null != hiddens) && (0 != hiddens.size())) {
/*  71 */       Set<Map.Entry<String, String>> set = hiddens.entrySet();
/*  72 */       Iterator<Map.Entry<String, String>> it = set.iterator();
/*  73 */       while (it.hasNext()) {
/*  74 */         Map.Entry<String, String> ey = (Map.Entry)it.next();
/*  75 */         String key = (String)ey.getKey();
/*  76 */         String value = (String)ey.getValue();
/*  77 */         sf.append("<input type=\"hidden\" name=\"" + key + "\" id=\"" + key + "\" value=\"" + value + "\"/>");
/*     */       }
/*     */     }
/*     */     
/*  81 */     sf.append("</form>");
/*  82 */     sf.append("</body>");
/*  83 */     sf.append("<script type=\"text/javascript\">");
/*  84 */     sf.append("document.all.pay_form.submit();");
/*  85 */     sf.append("</script>");
/*  86 */     sf.append("</html>");
/*  87 */     return sf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> signData(Map<String, ?> contentData, String certPath, String certPwd)
/*     */   {
/*  99 */     Map.Entry<String, String> obj = null;
/* 100 */     Map<String, String> submitFromData = new HashMap();
/* 101 */     for (Iterator<?> it = contentData.entrySet().iterator(); it.hasNext();) {
/* 102 */       obj = (Map.Entry)it.next();
/* 103 */       String value = (String)obj.getValue();
/* 104 */       if (StringUtils.isNotBlank(value))
/*     */       {
/* 106 */         submitFromData.put(obj.getKey(), value.trim());
/* 107 */         System.out.println((String)obj.getKey() + "-->" + String.valueOf(value));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 114 */     SDKUtil.signByCertInfo(submitFromData, encoding, certPath, certPwd);
/* 115 */     return submitFromData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> submitUrl(Map<String, String> submitFromData, String requestUrl)
/*     */   {
/* 126 */     String resultString = "";
/* 127 */     System.out.println("requestUrl====" + requestUrl);
/* 128 */     System.out.println("submitFromData====" + submitFromData.toString());
/*     */     
/*     */ 
/*     */ 
/* 132 */     HttpClient hc = new HttpClient(requestUrl, 30000, 30000);
/*     */     try {
/* 134 */       int status = hc.send(submitFromData, encoding);
/* 135 */       if (200 == status) {
/* 136 */         resultString = hc.getResult();
/*     */       }
/*     */     } catch (Exception e) {
/* 139 */       e.printStackTrace();
/*     */     }
/* 141 */     Map<String, String> resData = new HashMap();
/*     */     
/*     */ 
/*     */ 
/* 145 */     if ((null != resultString) && (!"".equals(resultString)))
/*     */     {
/* 147 */       resData = SDKUtil.convertResultStringToMap(resultString);
/* 148 */       if (SDKUtil.validate(resData, encoding)) {
/* 149 */         System.out.println("验证签名成功");
/*     */       } else {
/* 151 */         System.out.println("验证签名失败");
/*     */       }
/*     */       
/* 154 */       System.out.println("打印返回报文：" + resultString);
/*     */     }
/* 156 */     return resData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void deCodeFileContent(Map<String, String> resData)
/*     */   {
/* 164 */     String fileContent = (String)resData.get("fileContent");
/* 165 */     if ((null != fileContent) && (!"".equals(fileContent))) {
/*     */       try {
/* 167 */         byte[] fileArray = SecureUtil.inflater(SecureUtil.base64Decode(fileContent.getBytes(encoding)));
/*     */         
/* 169 */         String root = "D:\\";
/* 170 */         String filePath = null;
/* 171 */         if (SDKUtil.isEmpty((String)resData.get("fileName"))) {
/* 172 */           filePath = root + File.separator + (String)resData.get("merId") + "_" + (String)resData.get("batchNo") + "_" + (String)resData.get("txnTime") + ".txt";
/*     */         }
/*     */         else
/*     */         {
/* 176 */           filePath = root + File.separator + (String)resData.get("fileName");
/*     */         }
/* 178 */         File file = new File(filePath);
/* 179 */         if (file.exists()) {
/* 180 */           file.delete();
/*     */         }
/* 182 */         file.createNewFile();
/* 183 */         FileOutputStream out = new FileOutputStream(file);
/* 184 */         out.write(fileArray, 0, fileArray.length);
/* 185 */         out.flush();
/* 186 */         out.close();
/*     */       }
/*     */       catch (UnsupportedEncodingException e) {
/* 189 */         e.printStackTrace();
/*     */       } catch (IOException e) {
/* 191 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> submitDate(Map<String, ?> contentData, String requestUrl, String certPath, String certPwd)
/*     */   {
/* 205 */     Map<String, String> submitFromData = signData(contentData, certPath, certPwd);
/*     */     
/*     */ 
/* 208 */     return submitUrl(submitFromData, requestUrl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCustomer(String encoding)
/*     */   {
/* 219 */     StringBuffer sf = new StringBuffer("{");
/*     */     
/* 221 */     String certifTp = "01";
/*     */     
/* 223 */     String certifId = "1301212386859081945";
/*     */     
/* 225 */     String customerNm = "测试";
/*     */     
/* 227 */     String phoneNo = "18613958987";
/*     */     
/* 229 */     String smsCode = "123311";
/*     */     
/* 231 */     String pin = "123213";
/*     */     
/* 233 */     String cvn2 = "400";
/*     */     
/* 235 */     String expired = "1212";
/* 236 */     sf.append("certifTp=" + certifTp + "&");
/* 237 */     sf.append("certifId=" + certifId + "&");
/* 238 */     sf.append("customerNm=" + customerNm + "&");
/* 239 */     sf.append("phoneNo=" + phoneNo + "&");
/* 240 */     sf.append("smsCode=" + smsCode + "&");
/*     */     
/*     */ 
/*     */ 
/* 244 */     sf.append("pin=" + pin + "&");
/*     */     
/*     */ 
/*     */ 
/* 248 */     sf.append("cvn2=" + cvn2 + "&");
/*     */     
/*     */ 
/*     */ 
/* 252 */     sf.append("expired=" + expired);
/* 253 */     sf.append("}");
/* 254 */     String customerInfo = sf.toString();
/*     */     try {
/* 256 */       return new String(SecureUtil.base64Encode(sf.toString().getBytes(encoding)));
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 259 */       e.printStackTrace();
/*     */     } catch (IOException e) {
/* 261 */       e.printStackTrace();
/*     */     }
/* 263 */     return customerInfo;
/*     */   }
/*     */   
/*     */   public static String getCurrentTime() {
/* 267 */     return DateUtil.formatDate(new Date(), "yyyyMMddHHmmss");
/*     */   }
/*     */   
/*     */   public static String getOrderId() {
/* 271 */     return DateUtil.formatDate(new Date(), "yyyyMMddHHmmss");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCardTransData(Map<String, ?> contentData, String encoding)
/*     */   {
/* 286 */     StringBuffer cardTransDataBuffer = new StringBuffer();
/*     */     
/*     */ 
/* 289 */     String ICCardData = "uduiadniodaiooxnnxnnada";
/* 290 */     String ICCardSeqNumber = "123";
/* 291 */     String track2Data = "testtrack2Datauidanidnaidiadiada231";
/* 292 */     String track3Data = "testtrack3Datadadaiiuiduiauiduia312117831";
/* 293 */     String transSendMode = "b";
/*     */     
/*     */ 
/* 296 */     StringBuffer track2Buffer = new StringBuffer();
/* 297 */     track2Buffer.append(contentData.get("merId")).append("|").append(contentData.get("orderId")).append("|").append(contentData.get("txnTime")).append("|").append(contentData.get("txnAmt")).append("|").append(track2Data);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 303 */     String encryptedTrack2 = SDKUtil.encryptTrack(track2Buffer.toString(), encoding);
/*     */     
/*     */ 
/*     */ 
/* 307 */     StringBuffer track3Buffer = new StringBuffer();
/* 308 */     track3Buffer.append(contentData.get("merId")).append("|").append(contentData.get("orderId")).append("|").append(contentData.get("txnTime")).append("|").append(contentData.get("txnAmt")).append("|").append(track3Data);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 314 */     String encryptedTrack3 = SDKUtil.encryptTrack(track3Buffer.toString(), encoding);
/*     */     
/*     */ 
/*     */ 
/* 318 */     Map<String, String> cardTransDataMap = new HashMap();
/* 319 */     cardTransDataMap.put("ICCardData", ICCardData);
/* 320 */     cardTransDataMap.put("ICCardSeqNumber", ICCardSeqNumber);
/* 321 */     cardTransDataMap.put("track2Data", encryptedTrack2);
/* 322 */     cardTransDataMap.put("track3Data", encryptedTrack3);
/* 323 */     cardTransDataMap.put("transSendMode", transSendMode);
/*     */     
/* 325 */     return "{" + SDKUtil.coverMap2String(cardTransDataMap) + "}";
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\multicert\DemoBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */