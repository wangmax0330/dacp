/*     */ package com.unionpay.acp.sdksample.back;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DK
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  24 */     String encoding = "UTF-8";
/*     */     
/*  26 */     int status = 0;
/*     */     
/*  28 */     String result = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  33 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  35 */     String requestUrl = SDKConfig.getConfig().getBackRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  40 */     Map<String, String> data = new HashMap();
/*     */     
/*  42 */     data.put("version", "5.0.0");
/*     */     
/*  44 */     data.put("encoding", encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  50 */     data.put("signMethod", "01");
/*     */     
/*  52 */     data.put("txnType", "11");
/*     */     
/*  54 */     data.put("txnSubType", "00");
/*     */     
/*  56 */     data.put("bizType", "000000");
/*     */     
/*  58 */     data.put("channelType", "07");
/*     */     
/*     */ 
/*     */ 
/*  62 */     data.put("backUrl", "http://localhost:8080/ACPTest/acp_back_url.do");
/*     */     
/*  64 */     data.put("accessType", "0");
/*     */     
/*  66 */     data.put("acqInsCode", "");
/*     */     
/*  68 */     data.put("merCatCode", "");
/*     */     
/*  70 */     data.put("merId", "012310048995503");
/*     */     
/*  72 */     data.put("merName", "");
/*     */     
/*  74 */     data.put("merAbbr", "");
/*     */     
/*  76 */     data.put("subMerId", "");
/*     */     
/*  78 */     data.put("subMerName", "");
/*     */     
/*  80 */     data.put("subMerAbbr", "");
/*     */     
/*  82 */     data.put("orderId", "34010105078112");
/*     */     
/*  84 */     data.put("txnTime", "20140902153021");
/*     */     
/*  86 */     data.put("accType", "01");
/*     */     
/*  88 */     data.put("accNo", "6226090212121212");
/*     */     
/*     */ 
/*     */ 
/*  92 */     data.put("txnAmt", "1");
/*     */     
/*  94 */     data.put("currencyCode", "156");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */     data.put("termId", "");
/*     */     
/* 102 */     data.put("reqReserved", "");
/*     */     
/* 104 */     data.put("reserved", "");
/*     */     
/* 106 */     data.put("riskRateInfo", "");
/*     */     
/* 108 */     data.put("encryptCertId", "");
/*     */     
/*     */ 
/* 111 */     data.put("issInsCode", "");
/*     */     
/*     */ 
/* 114 */     data.put("customerIp", "172.17.136.111");
/*     */     
/* 116 */     data.put("bindId", "");
/*     */     
/*     */ 
/* 119 */     data.put("cardTransData", "");
/*     */     
/* 121 */     data.put("vpcTransData", "");
/*     */     
/* 123 */     data.put("orderDesc", "");
/*     */     
/*     */ 
/* 126 */     Map<String, String> request = new HashMap();
/* 127 */     request.putAll(data);
/* 128 */     Set<String> set = data.keySet();
/* 129 */     Iterator<String> iterator = set.iterator();
/* 130 */     while (iterator.hasNext()) {
/* 131 */       String key = (String)iterator.next();
/* 132 */       if ((null == data.get(key)) || ("".equals(data.get(key)))) {
/* 133 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 139 */     SDKUtil.sign(request, encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 144 */     HttpClient hc = new HttpClient(requestUrl, 30000, 30000);
/*     */     try
/*     */     {
/* 147 */       status = hc.send(request, encoding);
/*     */     } catch (Exception e) {
/* 149 */       e.printStackTrace();
/*     */     }
/*     */     
/* 152 */     if (200 == status)
/*     */     {
/* 154 */       result = hc.getResult();
/*     */       
/*     */ 
/*     */ 
/* 158 */       System.out.println("返回报文=[" + result + "]");
/*     */       
/* 160 */       if ((null != result) && (!"".equals(result)))
/*     */       {
/* 162 */         Map<String, String> resData = SDKUtil.convertResultStringToMap(result);
/*     */         
/* 164 */         String respcode = (String)resData.get("respCode");
/* 165 */         System.out.println("返回报文中应答码respCode=[" + respcode + "]");
/* 166 */         System.out.println("返回报文中应答respMsg=[" + (String)resData.get("respMsg") + "]");
/* 167 */         System.out.println("返回报文中应答resData=[" + resData + "]");
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 172 */         if (SDKUtil.validate(resData, encoding)) {
/* 173 */           System.out.println("商户端验证签名成功");
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 178 */           System.out.println("商户端验证签名失败");
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 185 */       result = hc.getResult();
/*     */       
/*     */ 
/*     */ 
/* 189 */       System.out.println("通信失败.");
/* 190 */       System.out.println("返回报文=[" + result + "]");
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\back\DK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */