/*     */ package com.unionpay.acp.sdksample.back;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MobilePay
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  19 */     String encoding = "UTF-8";
/*     */     
/*  21 */     int status = 0;
/*     */     
/*  23 */     String result = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  28 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  30 */     String requestUrl = SDKConfig.getConfig().getBackRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  35 */     Map<String, String> data = new HashMap();
/*     */     
/*  37 */     data.put("version", "5.0.0");
/*     */     
/*  39 */     data.put("encoding", encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */     data.put("signMethod", "01");
/*     */     
/*  47 */     data.put("txnType", "01");
/*     */     
/*  49 */     data.put("txnSubType", "01");
/*     */     
/*  51 */     data.put("bizType", "000000");
/*     */     
/*  53 */     data.put("channelType", "08");
/*     */     
/*     */ 
/*     */ 
/*  57 */     data.put("backUrl", "http://localhost:8080/ACPTest/acp_back_url.do");
/*     */     
/*  59 */     data.put("accessType", "0");
/*     */     
/*  61 */     data.put("acqInsCode", "");
/*     */     
/*  63 */     data.put("merCatCode", "");
/*     */     
/*  65 */     data.put("merId", "898340183980105");
/*     */     
/*  67 */     data.put("merName", "");
/*     */     
/*  69 */     data.put("merAbbr", "");
/*     */     
/*  71 */     data.put("subMerId", "");
/*     */     
/*  73 */     data.put("subMerName", "");
/*     */     
/*  75 */     data.put("subMerAbbr", "");
/*     */     
/*  77 */     data.put("orderId", "34010105078112");
/*     */     
/*  79 */     data.put("txnTime", "20140714120021");
/*     */     
/*  81 */     data.put("accType", "");
/*     */     
/*  83 */     data.put("accNo", "");
/*     */     
/*     */ 
/*     */ 
/*  87 */     data.put("txnAmt", "1");
/*     */     
/*  89 */     data.put("currencyCode", "156");
/*     */     
/*  91 */     data.put("customerInfo", Common.getCustomer(encoding));
/*     */     
/*  93 */     data.put("orderTimeout", "");
/*     */     
/*  95 */     data.put("payTimeout", "");
/*     */     
/*  97 */     data.put("termId", "");
/*     */     
/*  99 */     data.put("reqReserved", "");
/*     */     
/* 101 */     data.put("reserved", "");
/*     */     
/* 103 */     data.put("riskRateInfo", "");
/*     */     
/* 105 */     data.put("encryptCertId", "");
/*     */     
/*     */ 
/*     */ 
/* 109 */     data.put("instalTransInfo", "");
/*     */     
/* 111 */     data.put("defaultPayType", "");
/*     */     
/* 113 */     data.put("issInsCode", "");
/*     */     
/* 115 */     data.put("supPayType", "");
/*     */     
/* 117 */     data.put("userMac", "");
/*     */     
/* 119 */     data.put("customerIp", "");
/*     */     
/* 121 */     data.put("bindId", "");
/*     */     
/* 123 */     data.put("payCardType", "0");
/*     */     
/* 125 */     data.put("securityType", "");
/*     */     
/* 127 */     data.put("cardTransData", "");
/*     */     
/* 129 */     data.put("vpcTransData", "");
/*     */     
/* 131 */     data.put("orderDesc", "");
/*     */     
/*     */ 
/* 134 */     Map<String, String> request = new HashMap();
/* 135 */     request.putAll(data);
/* 136 */     Set<String> set = data.keySet();
/* 137 */     Iterator<String> iterator = set.iterator();
/* 138 */     while (iterator.hasNext()) {
/* 139 */       String key = (String)iterator.next();
/* 140 */       if ((null == data.get(key)) || ("".equals(data.get(key)))) {
/* 141 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 147 */     SDKUtil.sign(request, encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 152 */     HttpClient hc = new HttpClient(requestUrl, 30000, 30000);
/*     */     try
/*     */     {
/* 155 */       status = hc.send(request, encoding);
/*     */     } catch (Exception e) {
/* 157 */       e.printStackTrace();
/*     */     }
/*     */     
/* 160 */     if (200 == status)
/*     */     {
/* 162 */       result = hc.getResult();
/*     */       
/*     */ 
/*     */ 
/* 166 */       System.out.println("返回报文=[" + result + "]");
/*     */       
/* 168 */       if ((null != result) && (!"".equals(result)))
/*     */       {
/* 170 */         Map<String, String> resData = SDKUtil.convertResultStringToMap(result);
/*     */         
/* 172 */         String respcode = (String)resData.get("respCode");
/* 173 */         System.out.println("返回报文中应答码respCode=[" + respcode + "]");
/*     */         
/*     */ 
/*     */         String tn;
/*     */         
/* 178 */         if (SDKUtil.validate(resData, encoding)) {
/* 179 */           System.out.println("商户端验证签名成功");
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */           tn = (String)resData.get("tn");
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 191 */           System.out.println("商户端验证签名失败");
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 197 */       result = hc.getResult();
/*     */       
/*     */ 
/*     */ 
/* 201 */       System.out.println("通信失败.");
/* 202 */       System.out.println("返回报文=[" + result + "]");
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\back\MobilePay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */