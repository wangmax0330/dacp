/*     */ package com.unionpay.acp.sdksample.back;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.LogUtil;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsynBackTrans
/*     */ {
/*     */   public Map<String, String> process()
/*     */   {
/*  22 */     String encoding = "UTF-8";
/*     */     
/*  24 */     String resString = "";
/*     */     
/*     */ 
/*     */ 
/*  28 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  30 */     String requestUrl = SDKConfig.getConfig().getBackRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*  34 */     Map<String, String> data = new HashMap();
/*     */     
/*  36 */     data.put("version", "5.0.0");
/*     */     
/*  38 */     data.put("encoding", encoding);
/*     */     
/*  40 */     data.put("signMethod", "01");
/*     */     
/*  42 */     data.put("txnType", "04");
/*     */     
/*  44 */     data.put("txnSubType", "00");
/*     */     
/*  46 */     data.put("bizType", "000000");
/*     */     
/*  48 */     data.put("channelType", "07");
/*     */     
/*  50 */     data.put("backUrl", "http://localhost:8080/ACPTest/acp_back_url.do");
/*     */     
/*  52 */     data.put("accessType", "0");
/*     */     
/*  54 */     data.put("acqInsCode", "");
/*     */     
/*  56 */     data.put("merCatCode", "");
/*     */     
/*  58 */     data.put("merId", "940410759997007");
/*     */     
/*  60 */     data.put("merName", "");
/*     */     
/*  62 */     data.put("merAbbr", "");
/*     */     
/*  64 */     data.put("subMerId", "");
/*     */     
/*  66 */     data.put("subMerName", "");
/*     */     
/*  68 */     data.put("subMerAbbr", "");
/*     */     
/*  70 */     data.put("orderId", "355847812026");
/*     */     
/*  72 */     data.put("origQryId", "201410170924561000408");
/*     */     
/*  74 */     data.put("txnTime", "20141017092456");
/*     */     
/*  76 */     data.put("txnAmt", "1");
/*     */     
/*  78 */     data.put("termId", "");
/*     */     
/*  80 */     data.put("reqReserved", "");
/*     */     
/*  82 */     data.put("reserved", "");
/*     */     
/*  84 */     data.put("vpcTransData", "");
/*     */     
/*     */ 
/*  87 */     Map<String, String> request = new HashMap();
/*  88 */     request.putAll(data);
/*  89 */     Set<String> set = data.keySet();
/*  90 */     Iterator<String> iterator = set.iterator();
/*  91 */     while (iterator.hasNext()) {
/*  92 */       String key = (String)iterator.next();
/*  93 */       if ("".equals(data.get(key))) {
/*  94 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 100 */     SDKUtil.sign(request, encoding);
/* 101 */     LogUtil.writeLog("交易请求报文如下：");
/* 102 */     LogUtil.printRequestLog(request);
/*     */     
/*     */ 
/*     */ 
/* 106 */     LogUtil.writeLog("后台交易地址== ：" + requestUrl);
/* 107 */     HttpClient hc = new HttpClient(requestUrl, 30000, 30000);
/*     */     try {
/* 109 */       int status = hc.send(request, encoding);
/* 110 */       if (200 == status) {
/* 111 */         resString = hc.getResult();
/*     */       } else {
/* 113 */         LogUtil.writeLog("发送请求报文失败(系统未开放或暂时关闭);请稍后再试");
/*     */       }
/*     */     } catch (Exception e) {
/* 116 */       e.printStackTrace();
/* 117 */       LogUtil.writeLog("发送请求报文失败(系统未开放或暂时关闭);请稍后再试");
/*     */     }
/*     */     
/* 120 */     Map<String, String> resultMap = new HashMap();
/* 121 */     String respcode = "";
/*     */     
/* 123 */     Map<String, String> resData = null;
/*     */     try {
/* 125 */       resData = SDKUtil.convertResultStringToMap(resString);
/*     */     } catch (Exception e) {
/* 127 */       e.printStackTrace();
/* 128 */       resultMap.put("respCode", "10");
/* 129 */       resultMap.put("respMsg", "报文格式错误");
/* 130 */       LogUtil.printResponseLog("返回报文： " + resultMap);
/* 131 */       return resultMap;
/*     */     }
/* 133 */     respcode = (String)resData.get("respCode");
/* 134 */     LogUtil.writeLog("接收返回报文中应答码respCode=[" + respcode + "]");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 139 */     if ((null != resString) && (!"".equals(resString))) {
/* 140 */       if (SDKUtil.validate(resData, encoding)) {
/* 141 */         System.out.println("验证签名成功");
/*     */       } else {
/* 143 */         System.out.println("验证签名失败");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 148 */     if (!"00".equals(respcode)) {
/* 149 */       resultMap.put("respCode", resData.get("respCode"));
/* 150 */       resultMap.put("respMsg", resData.get("respMsg"));
/* 151 */       LogUtil.printResponseLog("应答报文打印： " + resultMap);
/* 152 */       return resultMap;
/*     */     }
/*     */     
/* 155 */     LogUtil.printResponseLog("应答报文打印： " + resString);
/*     */     
/* 157 */     Map<String, String> queryResultMap = queryProcess();
/*     */     
/* 159 */     String origRespcode = (String)queryResultMap.get("origRespCode");
/* 160 */     LogUtil.writeLog("第==1==次查询返回 ： OrigRespcode:" + origRespcode + ",RespCode:" + (String)queryResultMap.get("respCode"));
/*     */     
/* 162 */     if ((StringUtils.isNotBlank(origRespcode)) && (("05".equals(origRespcode)) || ("34".equals(origRespcode))))
/*     */     {
/* 164 */       int queryTimes = 5;
/* 165 */       for (int i = 1; i < queryTimes; i++) {
/* 166 */         Integer sleepTime = Integer.valueOf((int)Math.pow(2.0D, i));
/*     */         try {
/* 168 */           Thread.sleep(sleepTime.intValue() * 1000);
/*     */           
/* 170 */           LogUtil.writeLog("发起第===" + (i + 1) + "===交易状查询");
/* 171 */           queryResultMap = queryProcess();
/* 172 */           LogUtil.writeLog("origRespcode:" + origRespcode);
/* 173 */           if ((null != queryResultMap) && (StringUtils.isNotBlank(origRespcode)) && (("00".equals(origRespcode)) || ("01".equals(origRespcode))))
/*     */           {
/*     */ 
/*     */ 
/* 177 */             if ("00".equals(origRespcode)) {
/* 178 */               LogUtil.writeLog("查询成功，退出查询");
/* 179 */             } else if ("01".equals(origRespcode)) {
/* 180 */               LogUtil.writeLog("交易失败，退出查询");
/*     */             }
/* 182 */             break;
/*     */           }
/*     */         } catch (Exception e) {
/* 185 */           e.printStackTrace();
/* 186 */           resultMap.put("respCode", "02");
/* 187 */           resultMap.put("respMsg", "查询出错！");
/* 188 */           LogUtil.writeLog("返回报文=" + resultMap);
/* 189 */           return resultMap;
/*     */         }
/*     */       }
/*     */     }
/* 193 */     queryResultMap.put("respTime", resData.get("respTime"));
/*     */     
/* 195 */     resultMap = queryResultMap;
/* 196 */     if ("00".equals(queryResultMap.get("respCode")))
/*     */     {
/* 198 */       resultMap.put("respCode", origRespcode);
/*     */     }
/* 200 */     LogUtil.writeLog("打印返回报文如下");
/* 201 */     LogUtil.printRequestLog(resultMap);
/* 202 */     return resultMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> queryProcess()
/*     */   {
/* 214 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/* 215 */     String queryUrl = SDKConfig.getConfig().getSingleQueryUrl();
/* 216 */     String encoding = "UTF-8";
/*     */     
/*     */ 
/*     */ 
/* 220 */     Map<String, String> queryData = new HashMap();
/*     */     
/* 222 */     queryData.put("version", "5.0.0");
/*     */     
/* 224 */     queryData.put("encoding", encoding);
/*     */     
/* 226 */     queryData.put("signMethod", "01");
/*     */     
/* 228 */     queryData.put("txnType", "00");
/*     */     
/* 230 */     queryData.put("txnSubType", "00");
/*     */     
/* 232 */     queryData.put("bizType", "000000");
/*     */     
/* 234 */     queryData.put("acqInsCode", "");
/*     */     
/* 236 */     queryData.put("accessType", "0");
/*     */     
/* 238 */     queryData.put("merId", "898340183980105");
/*     */     
/* 240 */     queryData.put("txnTime", "20141017102920");
/*     */     
/* 242 */     queryData.put("orderId", "508aa0a8b414e01042e93b92862f5ac");
/*     */     
/* 244 */     queryData.put("queryId", "201410171029201000508");
/*     */     
/* 246 */     queryData.put("reserved", "");
/*     */     
/*     */ 
/* 249 */     Map<String, String> request = new HashMap();
/* 250 */     request.putAll(queryData);
/* 251 */     Set<String> set = queryData.keySet();
/* 252 */     Iterator<String> iterator = set.iterator();
/* 253 */     while (iterator.hasNext()) {
/* 254 */       String key = (String)iterator.next();
/* 255 */       if ((null == queryData.get(key)) || ("".equals(queryData.get(key)))) {
/* 256 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 263 */     SDKUtil.sign(request, encoding);
/* 264 */     LogUtil.writeLog("查询的queryUrl==  " + queryUrl);
/* 265 */     LogUtil.writeLog("查询请求报文如下");
/* 266 */     LogUtil.printRequestLog(request);
/*     */     
/*     */ 
/*     */ 
/* 270 */     HttpClient hc = new HttpClient(queryUrl, 30000, 30000);
/*     */     
/* 272 */     String queryResultString = "";
/*     */     try {
/* 274 */       int status = hc.send(request, encoding);
/* 275 */       if (200 == status) {
/* 276 */         queryResultString = hc.getResult();
/*     */       } else {
/* 278 */         LogUtil.writeLog("发送查询请求报文失败（系统未开放或暂时关闭）");
/* 279 */         LogUtil.writeLog("  返回信息为空，请稍后再试  ");
/*     */       }
/*     */     } catch (Exception e) {
/* 282 */       e.printStackTrace();
/* 283 */       LogUtil.writeLog("发送查询请求报文失败（系统未开放或暂时关闭）");
/* 284 */       LogUtil.writeLog("  返回信息为空，请稍后再试  ");
/*     */     }
/*     */     
/* 287 */     Map<String, String> resData = null;
/*     */     
/*     */ 
/*     */ 
/* 291 */     if ((null != queryResultString) && (!"".equals(queryResultString)))
/*     */     {
/* 293 */       resData = SDKUtil.convertResultStringToMap(queryResultString);
/* 294 */       LogUtil.writeLog("接收返回报文中应答码respCode=[" + (String)resData.get("respCode") + "]");
/*     */       
/*     */ 
/*     */ 
/* 298 */       if (SDKUtil.validate(resData, encoding)) {
/* 299 */         System.out.println("验证签名成功");
/*     */       } else {
/* 301 */         System.out.println("验证签名失败");
/*     */       }
/*     */       
/* 304 */       LogUtil.writeLog("查询返回报文如下");
/* 305 */       LogUtil.printResponseLog(queryResultString);
/*     */     }
/* 307 */     return resData;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 311 */     AsynBackTrans test = new AsynBackTrans();
/* 312 */     test.process();
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\back\AsynBackTrans.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */