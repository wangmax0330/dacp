/*     */ package com.unionpay.acp.sdksample.back;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BackPay
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  22 */     String encoding = "UTF-8";
/*     */     
/*  24 */     int status = 0;
/*     */     
/*  26 */     String result = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  31 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  33 */     String requestUrl = SDKConfig.getConfig().getBackRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  38 */     Map<String, String> data = new HashMap();
/*     */     
/*  40 */     data.put("version", "5.0.0");
/*     */     
/*  42 */     data.put("encoding", encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */     data.put("signMethod", "01");
/*     */     
/*  50 */     data.put("txnType", "01");
/*     */     
/*  52 */     data.put("txnSubType", "01");
/*     */     
/*  54 */     data.put("bizType", "000000");
/*     */     
/*  56 */     data.put("channelType", "08");
/*     */     
/*     */ 
/*     */ 
/*  60 */     data.put("backUrl", "http://localhost:8080/ACPTest/acp_back_url.do");
/*     */     
/*  62 */     data.put("accessType", "0");
/*     */     
/*  64 */     data.put("acqInsCode", "");
/*     */     
/*  66 */     data.put("merCatCode", "");
/*     */     
/*  68 */     data.put("merId", "898340183980105");
/*     */     
/*  70 */     data.put("merName", "");
/*     */     
/*  72 */     data.put("merAbbr", "");
/*     */     
/*  74 */     data.put("subMerId", "");
/*     */     
/*  76 */     data.put("subMerName", "");
/*     */     
/*  78 */     data.put("subMerAbbr", "");
/*     */     
/*  80 */     data.put("orderId", "34010105078112");
/*     */     
/*  82 */     data.put("txnTime", "20140923120021");
/*     */     
/*  84 */     data.put("accType", "");
/*     */     
/*  86 */     data.put("accNo", "");
/*     */     
/*     */ 
/*     */ 
/*  90 */     data.put("txnAmt", "1");
/*     */     
/*  92 */     data.put("currencyCode", "156");
/*     */     
/*  94 */     data.put("customerInfo", Common.getCustomer(encoding));
/*     */     
/*  96 */     data.put("orderTimeout", "");
/*     */     
/*  98 */     data.put("payTimeout", "");
/*     */     
/* 100 */     data.put("termId", "");
/*     */     
/* 102 */     data.put("reqReserved", "");
/*     */     
/* 104 */     data.put("reserved", "");
/*     */     
/* 106 */     data.put("riskRateInfo", "");
/*     */     
/* 108 */     data.put("encryptCertId", "");
/*     */     
/*     */ 
/*     */ 
/* 112 */     data.put("instalTransInfo", "");
/*     */     
/* 114 */     data.put("defaultPayType", "");
/*     */     
/* 116 */     data.put("issInsCode", "");
/*     */     
/* 118 */     data.put("supPayType", "");
/*     */     
/* 120 */     data.put("userMac", "");
/*     */     
/* 122 */     data.put("customerIp", "");
/*     */     
/* 124 */     data.put("bindId", "");
/*     */     
/*     */ 
/*     */ 
/* 128 */     data.put("securityType", "");
/*     */     
/* 130 */     data.put("cardTransData", "");
/*     */     
/* 132 */     data.put("vpcTransData", "");
/*     */     
/* 134 */     data.put("orderDesc", "");
/*     */     
/*     */ 
/* 137 */     Map<String, String> request = new HashMap();
/* 138 */     request.putAll(data);
/* 139 */     Set<String> set = data.keySet();
/* 140 */     Iterator<String> iterator = set.iterator();
/* 141 */     while (iterator.hasNext()) {
/* 142 */       String key = (String)iterator.next();
/* 143 */       if ((data.get(key) == null) || ("".equals(data.get(key)))) {
/* 144 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 150 */     SDKUtil.sign(request, encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 155 */     HttpClient hc = new HttpClient(requestUrl, 30000, 30000);
/*     */     try
/*     */     {
/* 158 */       status = hc.send(request, encoding);
/*     */       
/* 160 */       System.out.println("certId:" + (String)request.get("certId"));
/*     */     } catch (Exception e) {
/* 162 */       e.printStackTrace();
/*     */     }
/*     */     
/* 165 */     if (200 == status)
/*     */     {
/* 167 */       result = hc.getResult();
/*     */       
/*     */ 
/*     */ 
/* 171 */       System.out.println("返回报文=[" + result + "]");
/*     */       
/* 173 */       if ((null != result) && (!"".equals(result)))
/*     */       {
/* 175 */         Map<String, String> resData = SDKUtil.convertResultStringToMap(result);
/*     */         
/* 177 */         String respcode = (String)resData.get("respCode");
/* 178 */         System.out.println("返回报文中应答码respCode=[" + respcode + "]");
/* 179 */         if (!respcode.startsWith("UPOG"))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 184 */           if (SDKUtil.validate(resData, encoding)) {
/* 185 */             System.out.println("商户端验证签名成功");
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 190 */             System.out.println("商户端验证签名失败");
/*     */           }
/*     */         }
/*     */         else {
/* 194 */           System.out.println("交易失败.");
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 200 */       result = hc.getResult();
/*     */       
/*     */ 
/*     */ 
/* 204 */       System.out.println("通信失败.");
/* 205 */       System.out.println("返回报文=[" + result + "]");
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\back\BackPay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */