/*     */ package com.unionpay.acp.sdksample.back;
/*     */ 
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BillQuery
/*     */ {
/*     */   public static void main(String[] args)
/*     */     throws IOException
/*     */   {
/*  26 */     String encoding = "UTF-8";
/*     */     
/*  28 */     String result = "";
/*     */     
/*     */ 
/*     */ 
/*  32 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  34 */     String requestUrl = SDKConfig.getConfig().getBackRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*  38 */     Map<String, String> data = new HashMap();
/*     */     
/*  40 */     data.put("version", "5.0.0");
/*     */     
/*  42 */     data.put("encoding", encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */     data.put("signMethod", "01");
/*     */     
/*  50 */     data.put("txnType", "73");
/*     */     
/*  52 */     data.put("txnSubType", "01");
/*     */     
/*  54 */     data.put("bizType", "000000");
/*     */     
/*  56 */     data.put("channelType", "08");
/*     */     
/*  58 */     data.put("accessType", "0");
/*     */     
/*  60 */     data.put("acqInsCode", "");
/*     */     
/*  62 */     data.put("merId", "898340183980105");
/*     */     
/*  64 */     data.put("merCatCode", "");
/*     */     
/*  66 */     data.put("merName", "");
/*     */     
/*  68 */     data.put("merAbbr", "");
/*     */     
/*  70 */     data.put("subMerId", "");
/*     */     
/*  72 */     data.put("subMerName", "");
/*     */     
/*  74 */     data.put("orderId", "34010105078112");
/*     */     
/*  76 */     data.put("txnTime", "20140717120021");
/*     */     
/*     */ 
/*  79 */     data.put("billType", "0100");
/*     */     
/*  81 */     data.put("billNo", "123456789012");
/*     */     
/*  83 */     data.put("districtCode", "2900");
/*     */     
/*  85 */     data.put("additionalDistrictCode", "");
/*     */     
/*  87 */     data.put("billMonth", "");
/*     */     
/*  89 */     String a = "a";
/*  90 */     String[] b = { "b1", "b2", "b3" };
/*     */     
/*  92 */     JSONArray jsonArr = new JSONArray();
/*  93 */     for (String obj : b) {
/*  94 */       JSONObject json = new JSONObject();
/*  95 */       json.put("key1", a);
/*  96 */       json.put("key2", obj);
/*  97 */       jsonArr.add(json);
/*     */     }
/*     */     
/*     */ 
/* 101 */     data.put("billQueryInfo", jsonArr.toString());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     System.out.println("== Json格式的数据 ==" + (String)data.get("billQueryInfo"));
/*     */     
/* 113 */     data.put("reqReserved", "");
/*     */     
/* 115 */     data.put("reserved", "");
/*     */     
/* 117 */     Map<String, String> request = new HashMap();
/* 118 */     request.putAll(data);
/* 119 */     Set<String> set = data.keySet();
/* 120 */     Iterator<String> iterator = set.iterator();
/* 121 */     while (iterator.hasNext()) {
/* 122 */       String key = (String)iterator.next();
/* 123 */       if ((null == data.get(key)) || ("".equals(data.get(key)))) {
/* 124 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 131 */     SDKUtil.sign(request, encoding);
/*     */     
/*     */ 
/*     */ 
/* 135 */     HttpClient hc = new HttpClient(requestUrl, 30000, 30000);
/*     */     try {
/* 137 */       int status = hc.send(request, encoding);
/* 138 */       if (200 == status) {
/* 139 */         result = hc.getResult();
/*     */       }
/*     */     } catch (Exception e) {
/* 142 */       e.printStackTrace();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 148 */     if ((null != result) && (!"".equals(result)))
/*     */     {
/* 150 */       Map<String, String> resData = SDKUtil.convertResultStringToMap(result);
/*     */       
/* 152 */       if (SDKUtil.validate(resData, encoding)) {
/* 153 */         System.out.println("验证签名成功");
/*     */       } else {
/* 155 */         System.out.println("验证签名失败");
/*     */       }
/*     */       
/* 158 */       System.out.println("打印返回报文：" + result);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\back\BillQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */