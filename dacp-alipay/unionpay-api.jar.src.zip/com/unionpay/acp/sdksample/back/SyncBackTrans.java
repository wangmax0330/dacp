/*     */ package com.unionpay.acp.sdksample.back;
/*     */ 
/*     */ import com.unionpay.acp.sdk.CertUtil;
/*     */ import com.unionpay.acp.sdk.HttpClient;
/*     */ import com.unionpay.acp.sdk.SDKConfig;
/*     */ import com.unionpay.acp.sdk.SDKUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncBackTrans
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  22 */     String encoding = "UTF-8";
/*     */     
/*  24 */     String result = "";
/*     */     
/*     */ 
/*     */ 
/*  28 */     SDKConfig.getConfig().loadPropertiesFromSrc();
/*     */     
/*  30 */     String requestUrl = SDKConfig.getConfig().getBackRequestUrl();
/*     */     
/*     */ 
/*     */ 
/*  34 */     Map<String, String> data = new HashMap();
/*     */     
/*  36 */     data.put("version", "5.0.0");
/*     */     
/*  38 */     data.put("encoding", encoding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */     data.put("signMethod", "01");
/*     */     
/*  46 */     data.put("txnType", "71");
/*     */     
/*  48 */     data.put("txnSubType", "00");
/*     */     
/*  50 */     data.put("bizType", "000000");
/*     */     
/*  52 */     data.put("channelType", "08");
/*     */     
/*  54 */     data.put("frontUrl", "http://localhost:8080/ACPTest/acp_front_url.do");
/*     */     
/*  56 */     data.put("accessType", "0");
/*     */     
/*  58 */     data.put("merId", "898340183980105");
/*     */     
/*  60 */     data.put("acqInsCode", "");
/*     */     
/*  62 */     data.put("merCatCode", "");
/*     */     
/*  64 */     data.put("merName", "");
/*     */     
/*  66 */     data.put("merAbbr", "");
/*     */     
/*  68 */     data.put("subMerId", "");
/*     */     
/*  70 */     data.put("subMerName", "");
/*     */     
/*  72 */     data.put("orderId", "34010105078112");
/*     */     
/*  74 */     data.put("txnTime", "201407150101240984378");
/*     */     
/*  76 */     data.put("currencyCode", "156");
/*     */     
/*  78 */     data.put("accType", "01");
/*     */     
/*  80 */     data.put("accNo", "9555542160000001");
/*     */     
/*     */ 
/*     */ 
/*  84 */     data.put("customerInfo", Common.getCustomer(encoding));
/*     */     
/*  86 */     data.put("reqReserved", "");
/*     */     
/*  88 */     data.put("reserved", "");
/*     */     
/*  90 */     data.put("encryptCertId", CertUtil.getEncryptCertId());
/*     */     
/*  92 */     data.put("userMac", "");
/*     */     
/*  94 */     data.put("securityType", "");
/*     */     
/*  96 */     data.put("cardTransData", "");
/*     */     
/*     */ 
/*  99 */     Map<String, String> request = new HashMap();
/* 100 */     request.putAll(data);
/* 101 */     Set<String> set = data.keySet();
/* 102 */     Iterator<String> iterator = set.iterator();
/* 103 */     while (iterator.hasNext()) {
/* 104 */       String key = (String)iterator.next();
/* 105 */       if ((null == data.get(key)) || ("".equals(data.get(key)))) {
/* 106 */         request.remove(key);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 112 */     SDKUtil.sign(request, encoding);
/*     */     
/*     */ 
/*     */ 
/* 116 */     HttpClient hc = new HttpClient(requestUrl, 30000, 30000);
/*     */     try {
/* 118 */       int status = hc.send(request, encoding);
/* 119 */       if (200 == status) {
/* 120 */         result = hc.getResult();
/*     */       }
/*     */     } catch (Exception e) {
/* 123 */       e.printStackTrace();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 128 */     if ((null != result) && (!"".equals(result)))
/*     */     {
/* 130 */       Map<String, String> resData = SDKUtil.convertResultStringToMap(result);
/*     */       
/* 132 */       if (SDKUtil.validate(resData, encoding)) {
/* 133 */         System.out.println("验证签名成功");
/*     */       } else {
/* 135 */         System.out.println("验证签名失败");
/*     */       }
/*     */       
/* 138 */       System.out.println(result);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\back\SyncBackTrans.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */