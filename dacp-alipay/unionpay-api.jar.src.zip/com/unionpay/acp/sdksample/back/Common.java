/*    */ package com.unionpay.acp.sdksample.back;
/*    */ 
/*    */ import com.unionpay.acp.sdk.SDKUtil;
/*    */ import com.unionpay.acp.sdk.SecureUtil;
/*    */ import java.io.IOException;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Common
/*    */ {
/*    */   public static String getCustomer(String encoding)
/*    */   {
/* 19 */     StringBuffer sf = new StringBuffer("{");
/*    */     
/* 21 */     String certifTp = "01";
/*    */     
/* 23 */     String certifId = "1301212386859081945";
/*    */     
/* 25 */     String customerNm = "测试";
/*    */     
/* 27 */     String phoneNo = "18613958987";
/*    */     
/* 29 */     String smsCode = "123311";
/*    */     
/* 31 */     String pin = "123213";
/*    */     
/* 33 */     String cvn2 = "400";
/*    */     
/* 35 */     String expired = "1212";
/* 36 */     sf.append("certifTp=" + certifTp + "&");
/* 37 */     sf.append("certifId=" + certifId + "&");
/* 38 */     sf.append("customerNm=" + customerNm + "&");
/* 39 */     sf.append("phoneNo=" + phoneNo + "&");
/* 40 */     sf.append("smsCode=" + smsCode + "&");
/*    */     
/* 42 */     sf.append("pin=" + SDKUtil.encryptPin("622188123456789", pin, encoding) + "&");
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 50 */     sf.append("cvn2=" + cvn2 + "&");
/*    */     
/*    */ 
/*    */ 
/* 54 */     sf.append("expired=" + expired);
/* 55 */     sf.append("}");
/* 56 */     String customerInfo = sf.toString();
/*    */     try {
/* 58 */       return new String(SecureUtil.base64Encode(sf.toString().getBytes(encoding)));
/*    */     }
/*    */     catch (UnsupportedEncodingException e) {
/* 61 */       e.printStackTrace();
/*    */     } catch (IOException e) {
/* 63 */       e.printStackTrace();
/*    */     }
/* 65 */     return customerInfo;
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdksample\back\Common.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */