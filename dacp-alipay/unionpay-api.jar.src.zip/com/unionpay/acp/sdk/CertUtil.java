/*     */ package com.unionpay.acp.sdk;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigInteger;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Security;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CertUtil
/*     */ {
/*  38 */   private static KeyStore keyStore = null;
/*     */   
/*  40 */   private static X509Certificate encryptCert = null;
/*     */   
/*  42 */   private static X509Certificate encryptTrackCert = null;
/*     */   
/*     */ 
/*     */ 
/*  46 */   private static X509Certificate validateCert = null;
/*     */   
/*  48 */   private static Map<String, X509Certificate> certMap = new HashMap();
/*     */   
/*  50 */   private static KeyStore certKeyStore = null;
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  56 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/*  63 */     initSignCert();
/*  64 */     initEncryptCert();
/*  65 */     initValidateCertFromDir();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void initSignCert()
/*     */   {
/*  72 */     LogUtil.writeLog("加载签名证书开始");
/*  73 */     if (null != keyStore) {
/*  74 */       keyStore = null;
/*     */     }
/*     */     try {
/*  77 */       keyStore = getKeyInfo(SDKConfig.getConfig().getSignCertPath(), SDKConfig.getConfig().getSignCertPwd(), SDKConfig.getConfig().getSignCertType());
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  81 */       LogUtil.writeErrorLog("加载签名证书失败", e);
/*     */     }
/*     */     
/*  84 */     LogUtil.writeLog("加载签名证书结束");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void initSignCert(String certFilePath, String certPwd)
/*     */   {
/*  92 */     LogUtil.writeLog("加载证书文件[" + certFilePath + "]和证书密码[" + certPwd + "]的签名证书开始.");
/*     */     
/*  94 */     File files = new File(certFilePath);
/*  95 */     if (!files.exists()) {
/*  96 */       LogUtil.writeLog("证书文件不存在,初始化签名证书失败.");
/*  97 */       return;
/*     */     }
/*  99 */     if (null != certKeyStore) {
/* 100 */       certKeyStore = null;
/*     */     }
/*     */     try {
/* 103 */       certKeyStore = getKeyInfo(certFilePath, certPwd, "PKCS12");
/*     */     } catch (IOException e) {
/* 105 */       LogUtil.writeErrorLog("加载签名证书失败", e);
/*     */     }
/* 107 */     LogUtil.writeLog("加载证书文件[" + certFilePath + "]和证书密码[" + certPwd + "]的签名证书结束.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void initEncryptCert()
/*     */   {
/* 116 */     LogUtil.writeLog("加载密码加密证书开始");
/* 117 */     encryptCert = initCert(SDKConfig.getConfig().getEncryptCertPath());
/* 118 */     encryptTrackCert = initCert(SDKConfig.getConfig().getEncryptTrackCertPath());
/* 119 */     LogUtil.writeLog("加载密码加密证书结束");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static X509Certificate initCert(String path)
/*     */   {
/* 127 */     encryptCertTemp = null;
/* 128 */     if ((null == path) || ("".equals(path))) {
/* 129 */       LogUtil.writeLog("加载密码加密证书路径是空");
/* 130 */       return encryptCertTemp;
/*     */     }
/* 132 */     CertificateFactory cf = null;
/* 133 */     FileInputStream in = null;
/*     */     try {
/* 135 */       cf = CertificateFactory.getInstance("X.509");
/* 136 */       in = new FileInputStream(path);
/* 137 */       encryptCertTemp = (X509Certificate)cf.generateCertificate(in);
/*     */       
/* 139 */       LogUtil.writeLog("[" + path + "][serialNumber=" + encryptCertTemp.getSerialNumber().toString() + "]");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */       return encryptCertTemp;
/*     */     }
/*     */     catch (CertificateException e)
/*     */     {
/* 142 */       LogUtil.writeErrorLog(path + "加密证书加载失败", e);
/*     */     } catch (FileNotFoundException e) {
/* 144 */       LogUtil.writeErrorLog(path + "加密证书加载失败,文件不存在", e);
/*     */     } finally {
/* 146 */       if (null != in) {
/*     */         try {
/* 148 */           in.close();
/*     */         } catch (IOException e) {
/* 150 */           LogUtil.writeErrorLog(e.toString());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void initValidateCertFromDir()
/*     */   {
/* 162 */     LogUtil.writeLog("从目录中加载验证签名证书开始.");
/* 163 */     certMap.clear();
/* 164 */     String filePath = SDKConfig.getConfig().getValidateCertDir();
/* 165 */     if ((null == filePath) || ("".equals(filePath))) {
/* 166 */       LogUtil.writeLog("验证签名证书路径配置为空.");
/* 167 */       return;
/*     */     }
/*     */     
/* 170 */     CertificateFactory cf = null;
/* 171 */     FileInputStream in = null;
/*     */     try
/*     */     {
/* 174 */       cf = CertificateFactory.getInstance("X.509");
/* 175 */       File fileDir = new File(filePath);
/* 176 */       File[] files = fileDir.listFiles(new CerFilter());
/* 177 */       for (int i = 0; i < files.length; i++) {
/* 178 */         File file = files[i];
/* 179 */         in = new FileInputStream(file.getAbsolutePath());
/* 180 */         validateCert = (X509Certificate)cf.generateCertificate(in);
/* 181 */         certMap.put(validateCert.getSerialNumber().toString(), validateCert);
/*     */         
/*     */ 
/* 184 */         LogUtil.writeLog("[" + file.getAbsolutePath() + "][serialNumber=" + validateCert.getSerialNumber().toString() + "]");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 193 */       if (null != in) {
/*     */         try {
/* 195 */           in.close();
/*     */         } catch (IOException e) {
/* 197 */           LogUtil.writeErrorLog(e.toString());
/*     */         }
/*     */       }
/*     */       
/* 201 */       LogUtil.writeLog("从目录中加载验证签名证书结束.");
/*     */     }
/*     */     catch (CertificateException e)
/*     */     {
/* 189 */       LogUtil.writeErrorLog("验证签名证书加载失败", e);
/*     */     } catch (FileNotFoundException e) {
/* 191 */       LogUtil.writeErrorLog("验证签名证书加载失败,证书文件不存在", e);
/*     */     } finally {
/* 193 */       if (null != in) {
/*     */         try {
/* 195 */           in.close();
/*     */         } catch (IOException e) {
/* 197 */           LogUtil.writeErrorLog(e.toString());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PrivateKey getSignCertPrivateKey()
/*     */   {
/*     */     try
/*     */     {
/* 211 */       Enumeration<String> aliasenum = keyStore.aliases();
/* 212 */       String keyAlias = null;
/* 213 */       if (aliasenum.hasMoreElements()) {
/* 214 */         keyAlias = (String)aliasenum.nextElement();
/*     */       }
/* 216 */       return (PrivateKey)keyStore.getKey(keyAlias, SDKConfig.getConfig().getSignCertPwd().toCharArray());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 220 */       LogUtil.writeErrorLog("获取签名证书的私钥失败", e); }
/* 221 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PrivateKey getSignCertPrivateKey(CertInfo certInfo)
/*     */   {
/*     */     try
/*     */     {
/* 233 */       keyStore = certInfo.getKeyStore();
/* 234 */       Enumeration<String> aliasenum = keyStore.aliases();
/* 235 */       String keyAlias = null;
/* 236 */       if (aliasenum.hasMoreElements()) {
/* 237 */         keyAlias = (String)aliasenum.nextElement();
/*     */       }
/* 239 */       return (PrivateKey)keyStore.getKey(keyAlias, certInfo.getPassword().toCharArray());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 243 */       LogUtil.writeErrorLog("获取签名证书的私钥失败", e); }
/* 244 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PrivateKey getSignCertPrivateKey(String certPath, String certPwd)
/*     */   {
/* 259 */     initSignCert(certPath, certPwd);
/*     */     try {
/* 261 */       Enumeration<String> aliasenum = certKeyStore.aliases();
/* 262 */       String keyAlias = null;
/* 263 */       if (aliasenum.hasMoreElements()) {
/* 264 */         keyAlias = (String)aliasenum.nextElement();
/*     */       }
/* 266 */       return (PrivateKey)certKeyStore.getKey(keyAlias, certPwd.toCharArray());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 270 */       LogUtil.writeErrorLog("获取[" + certPath + "]的签名证书的私钥失败", e); }
/* 271 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PublicKey getEncryptCertPublicKey()
/*     */   {
/* 281 */     String path = SDKConfig.getConfig().getEncryptCertPath();
/*     */     try {
/* 283 */       if (null == encryptCert) {
/* 284 */         encryptCert = initCert(path);
/*     */       }
/* 286 */       return encryptCert.getPublicKey();
/*     */     } catch (Exception e) {
/* 288 */       LogUtil.writeErrorLog("获取加密证书失败" + path, e); }
/* 289 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PublicKey getEncryptTrackCertPublicKey()
/*     */   {
/* 300 */     String path = SDKConfig.getConfig().getEncryptTrackCertPath();
/*     */     try {
/* 302 */       if (null == path) {
/* 303 */         LogUtil.writeErrorLog("磁道加密证书没有配制");
/* 304 */         return null;
/*     */       }
/* 306 */       if (null == encryptTrackCert) {
/* 307 */         encryptTrackCert = initCert(path);
/*     */       }
/* 309 */       return encryptTrackCert.getPublicKey();
/*     */     } catch (Exception e) {
/* 311 */       LogUtil.writeErrorLog("获取磁道加密证书失败" + path, e); }
/* 312 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PublicKey getValidateKey()
/*     */   {
/*     */     try
/*     */     {
/* 330 */       if (null == validateCert) {
/* 331 */         return null;
/*     */       }
/* 333 */       return validateCert.getPublicKey();
/*     */     } catch (Exception e) {
/* 335 */       LogUtil.writeErrorLog("获取验证签名证书失败", e); }
/* 336 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PublicKey getValidateKey(String certId)
/*     */   {
/* 349 */     X509Certificate cf = null;
/* 350 */     if (certMap.containsKey(certId))
/*     */     {
/* 352 */       cf = (X509Certificate)certMap.get(certId);
/* 353 */       return cf.getPublicKey();
/*     */     }
/*     */     
/* 356 */     initValidateCertFromDir();
/* 357 */     if (certMap.containsKey(certId))
/*     */     {
/* 359 */       cf = (X509Certificate)certMap.get(certId);
/* 360 */       return cf.getPublicKey();
/*     */     }
/* 362 */     LogUtil.writeErrorLog("没有certId=[" + certId + "]对应的验签证书文件,返回NULL.");
/*     */     
/* 364 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSignCertId()
/*     */   {
/*     */     try
/*     */     {
/* 378 */       Enumeration<String> aliasenum = keyStore.aliases();
/* 379 */       String keyAlias = null;
/* 380 */       if (aliasenum.hasMoreElements()) {
/* 381 */         keyAlias = (String)aliasenum.nextElement();
/*     */       }
/* 383 */       X509Certificate cert = (X509Certificate)keyStore.getCertificate(keyAlias);
/*     */       
/* 385 */       return cert.getSerialNumber().toString();
/*     */     } catch (Exception e) {
/* 387 */       LogUtil.writeErrorLog("获取签名证书的序列号失败", e);
/* 388 */       if (null == keyStore)
/* 389 */         LogUtil.writeErrorLog("keyStore实例化失败,当前为NULL");
/*     */     }
/* 391 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSignCertId(KeyStore keyStore)
/*     */   {
/*     */     try
/*     */     {
/* 401 */       Enumeration<String> aliasenum = keyStore.aliases();
/* 402 */       String keyAlias = null;
/* 403 */       if (aliasenum.hasMoreElements()) {
/* 404 */         keyAlias = (String)aliasenum.nextElement();
/*     */       }
/* 406 */       X509Certificate cert = (X509Certificate)keyStore.getCertificate(keyAlias);
/*     */       
/* 408 */       return cert.getSerialNumber().toString();
/*     */     } catch (Exception e) {
/* 410 */       LogUtil.writeErrorLog("获取签名证书的序列号失败", e);
/* 411 */       if (null == keyStore)
/* 412 */         LogUtil.writeErrorLog("keyStore实例化失败,当前为NULL");
/*     */     }
/* 414 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getEncryptCertId()
/*     */   {
/*     */     try
/*     */     {
/* 425 */       if (null == encryptCert) {
/* 426 */         encryptCert = initCert(SDKConfig.getConfig().getEncryptCertPath());
/*     */       }
/* 428 */       return encryptCert.getSerialNumber().toString();
/*     */     } catch (Exception e) {
/* 430 */       LogUtil.writeErrorLog("获取加密证书的序列号失败", e); }
/* 431 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getEncryptTrackCertId()
/*     */   {
/*     */     try
/*     */     {
/* 443 */       if (null == encryptTrackCert) {
/* 444 */         encryptTrackCert = initCert(SDKConfig.getConfig().getEncryptTrackCertPath());
/*     */       }
/* 446 */       return encryptTrackCert.getSerialNumber().toString();
/*     */     } catch (Exception e) {
/* 448 */       LogUtil.writeErrorLog("获取加密磁道证书的序列号失败", e); }
/* 449 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PublicKey getSignPublicKey()
/*     */   {
/*     */     try
/*     */     {
/* 460 */       Enumeration<String> aliasenum = keyStore.aliases();
/* 461 */       String keyAlias = null;
/* 462 */       if (aliasenum.hasMoreElements())
/*     */       {
/*     */ 
/* 465 */         keyAlias = (String)aliasenum.nextElement();
/*     */       }
/*     */       
/* 468 */       Certificate cert = keyStore.getCertificate(keyAlias);
/* 469 */       return cert.getPublicKey();
/*     */     }
/*     */     catch (Exception e) {
/* 472 */       LogUtil.writeErrorLog(e.toString()); }
/* 473 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static KeyStore getKeyInfo(String pfxkeyfile, String keypwd, String type)
/*     */     throws IOException
/*     */   {
/* 492 */     FileInputStream fis = null;
/*     */     try {
/* 494 */       LogUtil.writeLog("KeyStore Loading Start...");
/* 495 */       KeyStore ks = null;
/* 496 */       if ("JKS".equals(type)) {
/* 497 */         ks = KeyStore.getInstance(type);
/* 498 */       } else if ("PKCS12".equals(type)) {
/* 499 */         Security.insertProviderAt(new BouncyCastleProvider(), 1);
/* 500 */         Security.addProvider(new BouncyCastleProvider());
/*     */         
/* 502 */         ks = KeyStore.getInstance(type);
/*     */       }
/* 504 */       LogUtil.writeLog("传入的私钥证书路径为=>[" + pfxkeyfile + "],密码=[" + keypwd + "]");
/*     */       
/* 506 */       fis = new FileInputStream(pfxkeyfile);
/* 507 */       nPassword = null;
/* 508 */       nPassword = (null == keypwd) || ("".equals(keypwd.trim())) ? null : keypwd.toCharArray();
/*     */       
/* 510 */       if (null != ks) {
/* 511 */         ks.load(fis, nPassword);
/*     */       }
/* 513 */       LogUtil.writeLog("KeyStore Loading End...");
/* 514 */       return ks;
/*     */     } catch (Exception e) { char[] nPassword;
/* 516 */       if (Security.getProvider("BC") == null) {
/* 517 */         LogUtil.writeLog("BC Provider not installed.");
/*     */       }
/* 519 */       LogUtil.writeErrorLog("读取私钥证书失败", e);
/* 520 */       if (((e instanceof KeyStoreException)) && ("PKCS12".equals(type))) {
/* 521 */         Security.removeProvider("BC");
/*     */       }
/* 523 */       return null;
/*     */     } finally {
/* 525 */       if (null != fis) {
/* 526 */         fis.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void printSysInfo() {
/* 532 */     System.out.println("======================= SYS INFO begin===========================");
/*     */     
/* 534 */     System.out.println("java_vendor:" + System.getProperty("java.vendor"));
/* 535 */     System.out.println("java_vendor_url:" + System.getProperty("java.vendor.url"));
/*     */     
/* 537 */     System.out.println("java_home:" + System.getProperty("java.home"));
/* 538 */     System.out.println("java_class_version:" + System.getProperty("java.class.version"));
/*     */     
/* 540 */     System.out.println("java_class_path:" + System.getProperty("java.class.path"));
/*     */     
/* 542 */     System.out.println("os_name:" + System.getProperty("os.name"));
/* 543 */     System.out.println("os_arch:" + System.getProperty("os.arch"));
/* 544 */     System.out.println("os_version:" + System.getProperty("os.version"));
/* 545 */     System.out.println("user_name:" + System.getProperty("user.name"));
/* 546 */     System.out.println("user_home:" + System.getProperty("user.home"));
/* 547 */     System.out.println("user_dir:" + System.getProperty("user.dir"));
/* 548 */     System.out.println("java_vm_specification_version:" + System.getProperty("java.vm.specification.version"));
/*     */     
/* 550 */     System.out.println("java_vm_specification_vendor:" + System.getProperty("java.vm.specification.vendor"));
/*     */     
/* 552 */     System.out.println("java_vm_specification_name:" + System.getProperty("java.vm.specification.name"));
/*     */     
/* 554 */     System.out.println("java_vm_version:" + System.getProperty("java.vm.version"));
/*     */     
/* 556 */     System.out.println("java_vm_vendor:" + System.getProperty("java.vm.vendor"));
/*     */     
/* 558 */     System.out.println("java_vm_name:" + System.getProperty("java.vm.name"));
/*     */     
/* 560 */     System.out.println("java_ext_dirs:" + System.getProperty("java.ext.dirs"));
/*     */     
/* 562 */     System.out.println("file_separator:" + System.getProperty("file.separator"));
/*     */     
/* 564 */     System.out.println("path_separator:" + System.getProperty("path.separator"));
/*     */     
/* 566 */     System.out.println("line_separator:" + System.getProperty("line.separator"));
/*     */     
/* 568 */     System.out.println("======================= SYS INFO end===========================");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class CerFilter
/*     */     implements FilenameFilter
/*     */   {
/*     */     public boolean isCer(String name)
/*     */     {
/* 580 */       if (name.toLowerCase().endsWith(".cer")) {
/* 581 */         return true;
/*     */       }
/* 583 */       return false;
/*     */     }
/*     */     
/*     */     public boolean accept(File dir, String name)
/*     */     {
/* 588 */       return isCer(name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCertIdByCertPath(String path, String pwd, String certTp)
/*     */   {
/* 603 */     KeyStore ks = null;
/*     */     try {
/* 605 */       ks = getKeyInfo(path, pwd, certTp);
/*     */     } catch (IOException e1) {
/* 607 */       LogUtil.writeErrorLog("加载签名证书失败", e1);
/*     */     }
/* 609 */     if (null == ks) {
/* 610 */       return "";
/*     */     }
/*     */     try {
/* 613 */       Enumeration<String> aliasenum = ks.aliases();
/* 614 */       String keyAlias = null;
/* 615 */       if (aliasenum.hasMoreElements()) {
/* 616 */         keyAlias = (String)aliasenum.nextElement();
/*     */       }
/* 618 */       X509Certificate cert = (X509Certificate)ks.getCertificate(keyAlias);
/*     */       
/* 620 */       return cert.getSerialNumber().toString();
/*     */     } catch (Exception e) {
/* 622 */       LogUtil.writeErrorLog("获取签名证书的序列号失败", e); }
/* 623 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, X509Certificate> getCertMap()
/*     */   {
/* 633 */     return certMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setCertMap(Map<String, X509Certificate> certMap)
/*     */   {
/* 642 */     certMap = certMap;
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdk\CertUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */