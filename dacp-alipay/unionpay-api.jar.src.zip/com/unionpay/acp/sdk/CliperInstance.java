/*    */ package com.unionpay.acp.sdk;
/*    */ 
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import javax.crypto.Cipher;
/*    */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*    */ 
/*    */ public class CliperInstance
/*    */ {
/*  9 */   private static ThreadLocal<Cipher> cipherTL = new ThreadLocal()
/*    */   {
/*    */     protected Cipher initialValue() {
/*    */       try {
/* 13 */         return Cipher.getInstance("RSA/ECB/PKCS1Padding", new BouncyCastleProvider());
/*    */       }
/*    */       catch (Exception e) {}
/*    */       
/*    */ 
/* 18 */       return null;
/*    */     }
/*    */   };
/*    */   
/*    */   public static Cipher getInstance()
/*    */     throws NoSuchAlgorithmException, javax.crypto.NoSuchPaddingException
/*    */   {
/* 25 */     return (Cipher)cipherTL.get();
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdk\CliperInstance.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */