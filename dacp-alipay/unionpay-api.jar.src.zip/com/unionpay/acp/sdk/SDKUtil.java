/*     */ package com.unionpay.acp.sdk;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SDKUtil
/*     */ {
/*  33 */   protected static char[] letter = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
/*     */   
/*     */ 
/*     */ 
/*  37 */   protected static final Random random = new Random();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String send(String url, Map<String, String> data, String encoding, int connectionTimeout, int readTimeout)
/*     */   {
/*  54 */     HttpClient hc = new HttpClient(url, connectionTimeout, readTimeout);
/*  55 */     String res = "";
/*     */     try {
/*  57 */       int status = hc.send(data, encoding);
/*  58 */       if (200 == status) {
/*  59 */         res = hc.getResult();
/*     */       }
/*     */     } catch (Exception e) {
/*  62 */       LogUtil.writeErrorLog("通信异常", e);
/*     */     }
/*  64 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean sign(Map<String, String> data, String encoding)
/*     */   {
/*  78 */     LogUtil.writeLog("签名处理开始.");
/*  79 */     if (isEmpty(encoding)) {
/*  80 */       encoding = "UTF-8";
/*     */     }
/*     */     
/*  83 */     data.put("certId", CertUtil.getSignCertId());
/*     */     
/*     */ 
/*  86 */     String stringData = coverMap2String(data);
/*  87 */     LogUtil.writeLog("报文签名之前的字符串(不含signature域)=[" + stringData + "]");
/*     */     
/*     */ 
/*     */ 
/*  91 */     byte[] byteSign = null;
/*  92 */     String stringSign = null;
/*     */     try
/*     */     {
/*  95 */       byte[] signDigest = SecureUtil.sha1X16(stringData, encoding);
/*  96 */       LogUtil.writeLog("SHA1->16进制转换后的摘要=[" + new String(signDigest) + "]");
/*     */       
/*  98 */       byteSign = SecureUtil.base64Encode(SecureUtil.signBySoft(CertUtil.getSignCertPrivateKey(), signDigest));
/*     */       
/* 100 */       stringSign = new String(byteSign);
/* 101 */       LogUtil.writeLog("报文签名之后的字符串=[" + stringSign + "]");
/*     */       
/* 103 */       data.put("signature", stringSign);
/* 104 */       LogUtil.writeLog("签名处理结束.");
/* 105 */       return true;
/*     */     } catch (Exception e) {
/* 107 */       LogUtil.writeErrorLog("签名异常", e); }
/* 108 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean signByCertInfo(Map<String, String> data, String encoding, String certPath, String certPwd)
/*     */   {
/* 128 */     LogUtil.writeLog("签名处理开始.");
/* 129 */     if (isEmpty(encoding)) {
/* 130 */       encoding = "UTF-8";
/*     */     }
/* 132 */     if ((isEmpty(certPath)) || (isEmpty(certPwd))) {
/* 133 */       LogUtil.writeLog("传入参数不合法,签名失败");
/* 134 */       return false;
/*     */     }
/*     */     
/* 137 */     data.put("certId", CertUtil.getCertIdByCertPath(certPath, certPwd, "PKCS12"));
/*     */     
/*     */ 
/* 140 */     String stringData = coverMap2String(data);
/* 141 */     LogUtil.writeLog("报文签名之前的字符串(不含signature域)=[" + stringData + "]");
/*     */     
/*     */ 
/*     */ 
/* 145 */     byte[] byteSign = null;
/* 146 */     String stringSign = null;
/*     */     try {
/* 148 */       byte[] signDigest = SecureUtil.sha1X16(stringData, encoding);
/* 149 */       LogUtil.writeLog("SHA1->16进制转换后的摘要=[" + new String(signDigest) + "]");
/*     */       
/* 151 */       byteSign = SecureUtil.base64Encode(SecureUtil.signBySoft(CertUtil.getSignCertPrivateKey(certPath, certPwd), signDigest));
/*     */       
/* 153 */       stringSign = new String(byteSign);
/* 154 */       LogUtil.writeLog("报文签名之后的字符串=[" + stringSign + "]");
/*     */       
/* 156 */       data.put("signature", stringSign);
/* 157 */       LogUtil.writeLog("签名处理结束.");
/* 158 */       return true;
/*     */     } catch (Exception e) {
/* 160 */       LogUtil.writeErrorLog("签名异常", e); }
/* 161 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean validate(Map<String, String> resData, String encoding)
/*     */   {
/* 176 */     LogUtil.writeLog("验签处理开始.");
/* 177 */     if (isEmpty(encoding)) {
/* 178 */       encoding = "UTF-8";
/*     */     }
/* 180 */     String stringSign = (String)resData.get("signature");
/* 181 */     LogUtil.writeLog("返回报文中signature=[" + stringSign + "]");
/*     */     
/*     */ 
/* 184 */     String certId = (String)resData.get("certId");
/* 185 */     LogUtil.writeLog("返回报文中certId=[" + certId + "]");
/*     */     
/*     */ 
/* 188 */     String stringData = coverMap2String(resData);
/* 189 */     LogUtil.writeLog("返回报文中(不含signature域)的stringData=[" + stringData + "]");
/*     */     
/*     */     try
/*     */     {
/* 193 */       return SecureUtil.validateSignBySoft(CertUtil.getValidateKey(certId), SecureUtil.base64Decode(stringSign.getBytes(encoding)), SecureUtil.sha1X16(stringData, encoding));
/*     */ 
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 198 */       LogUtil.writeErrorLog(e.getMessage(), e);
/*     */     } catch (Exception e) {
/* 200 */       LogUtil.writeErrorLog(e.getMessage(), e);
/*     */     }
/* 202 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String coverMap2String(Map<String, String> data)
/*     */   {
/* 213 */     TreeMap<String, String> tree = new TreeMap();
/* 214 */     Iterator<Map.Entry<String, String>> it = data.entrySet().iterator();
/* 215 */     while (it.hasNext()) {
/* 216 */       Map.Entry<String, String> en = (Map.Entry)it.next();
/* 217 */       if (!"signature".equals(((String)en.getKey()).trim()))
/*     */       {
/*     */ 
/* 220 */         tree.put(en.getKey(), en.getValue()); }
/*     */     }
/* 222 */     it = tree.entrySet().iterator();
/* 223 */     StringBuffer sf = new StringBuffer();
/* 224 */     while (it.hasNext()) {
/* 225 */       Map.Entry<String, String> en = (Map.Entry)it.next();
/* 226 */       sf.append((String)en.getKey() + "=" + (String)en.getValue() + "&");
/*     */     }
/*     */     
/* 229 */     return sf.substring(0, sf.length() - 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> coverResultString2Map(String result)
/*     */   {
/* 240 */     return convertResultStringToMap(result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> convertResultStringToMap(String result)
/*     */   {
/* 250 */     Map<String, String> map = null;
/*     */     try
/*     */     {
/* 253 */       if (StringUtils.isNotBlank(result)) {
/* 254 */         if ((result.startsWith("{")) && (result.endsWith("}"))) {
/* 255 */           System.out.println(result.length());
/* 256 */           result = result.substring(1, result.length() - 1);
/*     */         }
/* 258 */         map = parseQString(result);
/*     */       }
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 262 */       e.printStackTrace();
/*     */     }
/* 264 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> parseQString(String str)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 279 */     Map<String, String> map = new HashMap();
/* 280 */     int len = str.length();
/* 281 */     StringBuilder temp = new StringBuilder();
/*     */     
/* 283 */     String key = null;
/* 284 */     boolean isKey = true;
/* 285 */     boolean isOpen = false;
/* 286 */     char openName = '\000';
/* 287 */     if (len > 0) {
/* 288 */       for (int i = 0; i < len; i++) {
/* 289 */         char curChar = str.charAt(i);
/* 290 */         if (isKey)
/*     */         {
/* 292 */           if (curChar == '=') {
/* 293 */             key = temp.toString();
/* 294 */             temp.setLength(0);
/* 295 */             isKey = false;
/*     */           } else {
/* 297 */             temp.append(curChar);
/*     */           }
/*     */         } else {
/* 300 */           if (isOpen) {
/* 301 */             if (curChar == openName) {
/* 302 */               isOpen = false;
/*     */             }
/*     */           }
/*     */           else {
/* 306 */             if (curChar == '{') {
/* 307 */               isOpen = true;
/* 308 */               openName = '}';
/*     */             }
/* 310 */             if (curChar == '[') {
/* 311 */               isOpen = true;
/* 312 */               openName = ']';
/*     */             }
/*     */           }
/* 315 */           if ((curChar == '&') && (!isOpen)) {
/* 316 */             putKeyValueToMap(temp, isKey, key, map);
/* 317 */             temp.setLength(0);
/* 318 */             isKey = true;
/*     */           } else {
/* 320 */             temp.append(curChar);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 325 */       putKeyValueToMap(temp, isKey, key, map);
/*     */     }
/* 327 */     return map;
/*     */   }
/*     */   
/*     */   private static void putKeyValueToMap(StringBuilder temp, boolean isKey, String key, Map<String, String> map)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 333 */     if (isKey) {
/* 334 */       key = temp.toString();
/* 335 */       if (key.length() == 0) {
/* 336 */         throw new RuntimeException("QString format illegal");
/*     */       }
/* 338 */       map.put(key, "");
/*     */     } else {
/* 340 */       if (key.length() == 0) {
/* 341 */         throw new RuntimeException("QString format illegal");
/*     */       }
/* 343 */       map.put(key, temp.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encryptPin(String card, String pwd, String encoding)
/*     */   {
/* 358 */     return SecureUtil.EncryptPin(pwd, card, encoding, CertUtil.getEncryptCertPublicKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encryptCvn2(String cvn2, String encoding)
/*     */   {
/* 372 */     return SecureUtil.EncryptData(cvn2, encoding, CertUtil.getEncryptCertPublicKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decryptCvn2(String base64cvn2, String encoding)
/*     */   {
/* 386 */     return SecureUtil.DecryptedData(base64cvn2, encoding, CertUtil.getSignCertPrivateKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encryptAvailable(String date, String encoding)
/*     */   {
/* 400 */     return SecureUtil.EncryptData(date, encoding, CertUtil.getEncryptCertPublicKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decryptAvailable(String base64Date, String encoding)
/*     */   {
/* 414 */     return SecureUtil.DecryptedData(base64Date, encoding, CertUtil.getSignCertPrivateKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encryptPan(String pan, String encoding)
/*     */   {
/* 428 */     return SecureUtil.EncryptData(pan, encoding, CertUtil.getEncryptCertPublicKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decryptPan(String base64Pan, String encoding)
/*     */   {
/* 441 */     return SecureUtil.DecryptedData(base64Pan, encoding, CertUtil.getSignCertPrivateKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encryptTrack(String trackData, String encoding)
/*     */   {
/* 456 */     return SecureUtil.EncryptData(trackData, encoding, CertUtil.getEncryptTrackCertPublicKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEmpty(String s)
/*     */   {
/* 469 */     return (null == s) || ("".equals(s.trim()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String generateTxnTime()
/*     */   {
/* 478 */     return new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String generateOrderId()
/*     */   {
/* 487 */     StringBuilder sb = new StringBuilder();
/* 488 */     int len = random.nextInt(18);
/* 489 */     for (int i = 0; i < len; i++) {
/* 490 */       sb.append(letter[i]);
/*     */     }
/* 492 */     return generateTxnTime() + sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createAutoSubmitForm(String url, Map<String, String> data)
/*     */   {
/* 504 */     StringBuffer sf = new StringBuffer();
/* 505 */     sf.append("<form id = \"sform\" action=\"" + url + "\" method=\"post\">");
/*     */     
/* 507 */     if ((null != data) && (0 != data.size())) {
/* 508 */       Set<Map.Entry<String, String>> set = data.entrySet();
/* 509 */       Iterator<Map.Entry<String, String>> it = set.iterator();
/* 510 */       while (it.hasNext()) {
/* 511 */         Map.Entry<String, String> ey = (Map.Entry)it.next();
/* 512 */         String key = (String)ey.getKey();
/* 513 */         String value = (String)ey.getValue();
/* 514 */         sf.append("<input type=\"hidden\" name=\"" + key + "\" id=\"" + key + "\" value=\"" + value + "\"/>");
/*     */       }
/*     */     }
/*     */     
/* 518 */     sf.append("</form>");
/* 519 */     sf.append("</body>");
/* 520 */     sf.append("<script type=\"text/javascript\">");
/* 521 */     sf.append("document.getElementById(\"sform\").submit();\n");
/* 522 */     sf.append("</script>");
/* 523 */     return sf.toString();
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 527 */     System.out.println(encryptTrack("12", "utf-8"));
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdk\SDKUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */