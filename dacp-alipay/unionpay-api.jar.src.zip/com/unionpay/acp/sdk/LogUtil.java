/*     */ package com.unionpay.acp.sdk;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogUtil
/*     */ {
/*  27 */   private static final Logger GATELOG = LoggerFactory.getLogger("ACP_SDK_LOG");
/*  28 */   private static final Logger GATELOG_ERROR = LoggerFactory.getLogger("SDK_ERR_LOG");
/*     */   
/*  30 */   private static final Logger GATELOG_MESSAGE = LoggerFactory.getLogger("SDK_MSG_LOG");
/*     */   
/*     */ 
/*     */   static final String LOG_STRING_REQ_MSG_BEGIN = "============================== SDK REQ MSG BEGIN ==============================";
/*     */   
/*     */   static final String LOG_STRING_REQ_MSG_END = "==============================  SDK REQ MSG END  ==============================";
/*     */   
/*     */   static final String LOG_STRING_RSP_MSG_BEGIN = "============================== SDK RSP MSG BEGIN ==============================";
/*     */   
/*     */   static final String LOG_STRING_RSP_MSG_END = "==============================  SDK RSP MSG END  ==============================";
/*     */   
/*     */ 
/*     */   public static void writeLog(String cont)
/*     */   {
/*  44 */     GATELOG.info(cont);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeLog(String cont, String frameId)
/*     */   {
/*  55 */     GATELOG.info("[" + frameId + "]" + cont);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeErrorLog(String cont)
/*     */   {
/*  64 */     GATELOG_ERROR.error(cont);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeErrorLog(String cont, String frameId)
/*     */   {
/*  75 */     GATELOG_ERROR.error("[" + frameId + "]" + cont);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeErrorLog(String cont, Throwable ex)
/*     */   {
/*  85 */     GATELOG_ERROR.error(cont, ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeErrorLog(String cont, String frameId, Throwable ex)
/*     */   {
/*  97 */     GATELOG_ERROR.error("[" + frameId + "]" + cont, ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeMessage(String msg)
/*     */   {
/* 106 */     GATELOG_MESSAGE.info(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void printRequestLog(Map<String, String> reqParam)
/*     */   {
/* 115 */     writeMessage("============================== SDK REQ MSG BEGIN ==============================");
/* 116 */     Iterator<Map.Entry<String, String>> it = reqParam.entrySet().iterator();
/* 117 */     while (it.hasNext()) {
/* 118 */       Map.Entry<String, String> en = (Map.Entry)it.next();
/* 119 */       writeMessage("[" + (String)en.getKey() + "] = [" + (String)en.getValue() + "]");
/*     */     }
/* 121 */     writeMessage("==============================  SDK REQ MSG END  ==============================");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void printResponseLog(String res)
/*     */   {
/* 130 */     writeMessage("============================== SDK RSP MSG BEGIN ==============================");
/* 131 */     writeMessage(res);
/* 132 */     writeMessage("==============================  SDK RSP MSG END  ==============================");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void trace(String cont)
/*     */   {
/* 141 */     if (GATELOG.isTraceEnabled()) {
/* 142 */       GATELOG.trace(cont);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void debug(String cont)
/*     */   {
/* 152 */     if (GATELOG.isDebugEnabled()) {
/* 153 */       GATELOG.debug(cont);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdk\LogUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */