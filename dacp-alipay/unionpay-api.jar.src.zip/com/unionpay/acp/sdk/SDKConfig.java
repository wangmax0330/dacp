/*     */ package com.unionpay.acp.sdk;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SDKConfig
/*     */ {
/*     */   public static final String FILE_NAME = "acp_sdk.properties";
/*     */   private String frontRequestUrl;
/*     */   private String backRequestUrl;
/*     */   private String singleQueryUrl;
/*     */   private String batchQueryUrl;
/*     */   private String batchTransUrl;
/*     */   private String fileTransUrl;
/*     */   private String signCertPath;
/*     */   private String signCertPwd;
/*     */   private String signCertType;
/*     */   private String encryptCertPath;
/*     */   private String validateCertPath;
/*     */   private String validateCertDir;
/*     */   private String signCertDir;
/*     */   private String encryptTrackCertPath;
/*     */   private String cardRequestUrl;
/*     */   private String appRequestUrl;
/*     */   public static final String SDK_FRONT_URL = "acpsdk.frontTransUrl";
/*     */   public static final String SDK_BACK_URL = "acpsdk.backTransUrl";
/*     */   public static final String SDK_SIGNQ_URL = "acpsdk.singleQueryUrl";
/*     */   public static final String SDK_BATQ_URL = "acpsdk.batchQueryUrl";
/*     */   public static final String SDK_BATTRANS_URL = "acpsdk.batchTransUrl";
/*     */   public static final String SDK_FILETRANS_URL = "acpsdk.fileTransUrl";
/*     */   public static final String SDK_CARD_URL = "acpsdk.cardTransUrl";
/*     */   public static final String SDK_APP_URL = "acpsdk.appTransUrl";
/*     */   public static final String SDK_SIGNCERT_PATH = "acpsdk.signCert.path";
/*     */   public static final String SDK_SIGNCERT_PWD = "acpsdk.signCert.pwd";
/*     */   public static final String SDK_SIGNCERT_TYPE = "acpsdk.signCert.type";
/*     */   public static final String SDK_ENCRYPTCERT_PATH = "acpsdk.encryptCert.path";
/*     */   public static final String SDK_VALIDATECERT_PATH = "acpsdk.validateCert.path";
/*     */   public static final String SDK_VALIDATECERT_DIR = "acpsdk.validateCert.dir";
/*     */   public static final String SDK_CVN_ENC = "acpsdk.cvn2.enc";
/*     */   public static final String SDK_DATE_ENC = "acpsdk.date.enc";
/*     */   public static final String SDK_PAN_ENC = "acpsdk.pan.enc";
/*     */   public static final String SDK_SIGNCERT_DIR = "acpsdk.signCert.dir";
/*     */   private static SDKConfig config;
/*     */   private Properties properties;
/* 126 */   private Map<String, CertInfo> certMaps = new TreeMap();
/*     */   public String rootPath;
/*     */   
/* 129 */   public Map<String, CertInfo> getCertMaps() { return this.certMaps; }
/*     */   
/*     */   public void setCertMaps(Map<String, CertInfo> certMaps)
/*     */   {
/* 133 */     this.certMaps = certMaps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SDKConfig getConfig()
/*     */   {
/* 142 */     if (null == config) {
/* 143 */       config = new SDKConfig();
/*     */     }
/* 145 */     return config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadPropertiesFromPath(String rootPath)
/*     */   {
/* 155 */     this.rootPath = rootPath;
/* 156 */     if (StringUtils.isNotBlank(rootPath)) {
/* 157 */       File file = new File(rootPath + File.separator + "acp_sdk.properties");
/* 158 */       InputStream in = null;
/* 159 */       if (file.exists()) {
/*     */         try {
/* 161 */           in = new FileInputStream(file);
/* 162 */           BufferedReader bf = new BufferedReader(new InputStreamReader(in, "utf-8"));
/*     */           
/* 164 */           this.properties = new Properties();
/* 165 */           this.properties.load(bf);
/* 166 */           loadProperties(this.properties);
/*     */         } catch (FileNotFoundException e) {
/* 168 */           e.printStackTrace();
/*     */         } catch (IOException e) {
/* 170 */           e.printStackTrace();
/*     */         } finally {
/* 172 */           if (null != in) {
/*     */             try {
/* 174 */               in.close();
/*     */             } catch (IOException e) {
/* 176 */               e.printStackTrace();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 182 */       System.out.println(rootPath + "acp_sdk.properties" + "不存在,加载参数失败");
/*     */     }
/*     */     else {
/* 185 */       loadPropertiesFromSrc();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadPropertiesFromSrc()
/*     */   {
/* 194 */     InputStream in = null;
/*     */     try
/*     */     {
/* 197 */       in = SDKConfig.class.getClassLoader().getResourceAsStream("acp_sdk.properties");
/*     */       
/* 199 */       if (null != in) {
/* 200 */         BufferedReader bf = new BufferedReader(new InputStreamReader(in, "utf-8"));
/*     */         
/* 202 */         this.properties = new Properties();
/*     */         try {
/* 204 */           this.properties.load(bf);
/*     */         } catch (IOException e) {
/* 206 */           throw e;
/*     */         }
/*     */       } else {
/* 209 */         LogUtil.writeErrorLog("acp_sdk.properties文件不存在!"); return;
/*     */       }
/*     */       
/* 212 */       loadProperties(this.properties); return;
/*     */     } catch (IOException e) {
/* 214 */       e.printStackTrace();
/*     */     } finally {
/* 216 */       if (null != in) {
/*     */         try {
/* 218 */           in.close();
/*     */         } catch (IOException e) {
/* 220 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadProperties(Properties pro)
/*     */   {
/* 232 */     String value = pro.getProperty("acpsdk.frontTransUrl");
/* 233 */     if (!SDKUtil.isEmpty(value)) {
/* 234 */       this.frontRequestUrl = value.trim();
/*     */     }
/* 236 */     value = pro.getProperty("acpsdk.backTransUrl");
/* 237 */     if (!SDKUtil.isEmpty(value)) {
/* 238 */       this.backRequestUrl = value.trim();
/*     */     }
/* 240 */     value = pro.getProperty("acpsdk.encryptCert.path");
/* 241 */     if (!SDKUtil.isEmpty(value)) {
/* 242 */       this.encryptCertPath = value.trim();
/*     */     }
/* 244 */     value = pro.getProperty("acpsdk.validateCert.path");
/* 245 */     if (!SDKUtil.isEmpty(value)) {
/* 246 */       this.validateCertPath = value.trim();
/*     */     }
/* 248 */     value = pro.getProperty("acpsdk.validateCert.dir");
/* 249 */     if (!SDKUtil.isEmpty(value)) {
/* 250 */       this.validateCertDir = value.trim();
/*     */     }
/* 252 */     value = pro.getProperty("acpsdk.batchQueryUrl");
/* 253 */     if (!SDKUtil.isEmpty(value)) {
/* 254 */       this.batchQueryUrl = value.trim();
/*     */     }
/* 256 */     value = pro.getProperty("acpsdk.batchTransUrl");
/* 257 */     if (!SDKUtil.isEmpty(value)) {
/* 258 */       this.batchTransUrl = value.trim();
/*     */     }
/* 260 */     value = pro.getProperty("acpsdk.fileTransUrl");
/* 261 */     if (!SDKUtil.isEmpty(value)) {
/* 262 */       this.fileTransUrl = value.trim();
/*     */     }
/* 264 */     value = pro.getProperty("acpsdk.singleQueryUrl");
/* 265 */     if (!SDKUtil.isEmpty(value)) {
/* 266 */       this.singleQueryUrl = value.trim();
/*     */     }
/* 268 */     value = pro.getProperty("acpsdk.signCert.dir");
/* 269 */     if (!SDKUtil.isEmpty(value)) {
/* 270 */       this.signCertDir = value.trim();
/*     */     }
/* 272 */     value = pro.getProperty("acpsdk.cardTransUrl");
/* 273 */     if (!SDKUtil.isEmpty(value)) {
/* 274 */       this.cardRequestUrl = value.trim();
/*     */     }
/* 276 */     value = pro.getProperty("acpsdk.appTransUrl");
/* 277 */     if (!SDKUtil.isEmpty(value)) {
/* 278 */       this.appRequestUrl = value.trim();
/*     */     }
/* 280 */     value = pro.getProperty("acpsdk.encryptTrackCert.path");
/* 281 */     if (!SDKUtil.isEmpty(value)) {
/* 282 */       this.encryptTrackCertPath = value.trim();
/*     */     }
/* 284 */     Iterator<Map.Entry<Object, Object>> iterator = pro.entrySet().iterator();
/* 285 */     while (iterator.hasNext()) {
/* 286 */       Map.Entry<Object, Object> types = (Map.Entry)iterator.next();
/* 287 */       setKey(this.certMaps, types, "acpsdk.signCert.path");
/* 288 */       setKey(this.certMaps, types, "acpsdk.signCert.pwd");
/* 289 */       setKey(this.certMaps, types, "acpsdk.signCert.type");
/*     */     }
/* 291 */     if (this.certMaps.entrySet().size() > 0) {
/* 292 */       Map.Entry<String, CertInfo> obj = (Map.Entry)this.certMaps.entrySet().iterator().next();
/* 293 */       this.signCertPath = ((CertInfo)obj.getValue()).getCertPath();
/* 294 */       this.signCertPwd = ((CertInfo)obj.getValue()).getPassword();
/* 295 */       this.signCertType = ((CertInfo)obj.getValue()).getKeyType();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setKey(Map<String, CertInfo> map, Map.Entry<Object, Object> propertisObj, CharSequence s)
/*     */   {
/* 309 */     if (String.valueOf(propertisObj.getKey()).contains(s)) {
/* 310 */       String key = String.valueOf(propertisObj.getKey()).replaceAll(s.toString(), "");
/*     */       
/*     */ 
/* 313 */       String keyName = "";
/* 314 */       CertInfo certinfo; CertInfo certinfo; if ("".equals(key)) {
/* 315 */         keyName = "00";
/* 316 */         certinfo = (CertInfo)map.get(keyName);
/*     */       } else {
/* 318 */         keyName = key;
/* 319 */         certinfo = (CertInfo)map.get(key);
/*     */       }
/* 321 */       if (certinfo == null) {
/* 322 */         certinfo = new CertInfo();
/*     */       }
/* 324 */       map.put(keyName, certinfo);
/* 325 */       if ("acpsdk.signCert.path".equals(s)) {
/* 326 */         certinfo.setCertPath(String.valueOf(propertisObj.getValue()));
/* 327 */       } else if ("acpsdk.signCert.pwd".equals(s)) {
/* 328 */         certinfo.setPassword(String.valueOf(propertisObj.getValue()));
/* 329 */       } else if ("acpsdk.signCert.type".equals(s)) {
/* 330 */         certinfo.setKeyType(String.valueOf(propertisObj.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFrontRequestUrl() {
/* 336 */     return this.frontRequestUrl;
/*     */   }
/*     */   
/*     */   public void setFrontRequestUrl(String frontRequestUrl) {
/* 340 */     this.frontRequestUrl = frontRequestUrl;
/*     */   }
/*     */   
/*     */   public String getBackRequestUrl() {
/* 344 */     return this.backRequestUrl;
/*     */   }
/*     */   
/*     */   public void setBackRequestUrl(String backRequestUrl) {
/* 348 */     this.backRequestUrl = backRequestUrl;
/*     */   }
/*     */   
/*     */   public String getSignCertPath() {
/* 352 */     return this.signCertPath;
/*     */   }
/*     */   
/*     */   public void setSignCertPath(String signCertPath) {
/* 356 */     this.signCertPath = signCertPath;
/*     */   }
/*     */   
/*     */   public String getSignCertPwd() {
/* 360 */     return this.signCertPwd;
/*     */   }
/*     */   
/*     */   public void setSignCertPwd(String signCertPwd) {
/* 364 */     this.signCertPwd = signCertPwd;
/*     */   }
/*     */   
/*     */   public String getSignCertType() {
/* 368 */     return this.signCertType;
/*     */   }
/*     */   
/*     */   public void setSignCertType(String signCertType) {
/* 372 */     this.signCertType = signCertType;
/*     */   }
/*     */   
/*     */   public String getEncryptCertPath() {
/* 376 */     return this.encryptCertPath;
/*     */   }
/*     */   
/*     */   public void setEncryptCertPath(String encryptCertPath) {
/* 380 */     this.encryptCertPath = encryptCertPath;
/*     */   }
/*     */   
/*     */   public String getValidateCertPath() {
/* 384 */     return this.validateCertPath;
/*     */   }
/*     */   
/*     */   public void setValidateCertPath(String validateCertPath) {
/* 388 */     this.validateCertPath = validateCertPath;
/*     */   }
/*     */   
/*     */   public String getValidateCertDir() {
/* 392 */     return this.validateCertDir;
/*     */   }
/*     */   
/*     */   public void setValidateCertDir(String validateCertDir) {
/* 396 */     this.validateCertDir = validateCertDir;
/*     */   }
/*     */   
/*     */   public String getSingleQueryUrl() {
/* 400 */     return this.singleQueryUrl;
/*     */   }
/*     */   
/*     */   public void setSingleQueryUrl(String singleQueryUrl) {
/* 404 */     this.singleQueryUrl = singleQueryUrl;
/*     */   }
/*     */   
/*     */   public String getBatchQueryUrl() {
/* 408 */     return this.batchQueryUrl;
/*     */   }
/*     */   
/*     */   public void setBatchQueryUrl(String batchQueryUrl) {
/* 412 */     this.batchQueryUrl = batchQueryUrl;
/*     */   }
/*     */   
/*     */   public String getBatchTransUrl() {
/* 416 */     return this.batchTransUrl;
/*     */   }
/*     */   
/*     */   public void setBatchTransUrl(String batchTransUrl) {
/* 420 */     this.batchTransUrl = batchTransUrl;
/*     */   }
/*     */   
/*     */   public String getFileTransUrl() {
/* 424 */     return this.fileTransUrl;
/*     */   }
/*     */   
/*     */   public void setFileTransUrl(String fileTransUrl) {
/* 428 */     this.fileTransUrl = fileTransUrl;
/*     */   }
/*     */   
/*     */   public String getSignCertDir() {
/* 432 */     return this.signCertDir;
/*     */   }
/*     */   
/*     */   public void setSignCertDir(String signCertDir) {
/* 436 */     this.signCertDir = signCertDir;
/*     */   }
/*     */   
/*     */   public Properties getProperties() {
/* 440 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Properties properties) {
/* 444 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   public String getCardRequestUrl() {
/* 448 */     return this.cardRequestUrl;
/*     */   }
/*     */   
/*     */   public void setCardRequestUrl(String cardRequestUrl) {
/* 452 */     this.cardRequestUrl = cardRequestUrl;
/*     */   }
/*     */   
/*     */   public String getAppRequestUrl() {
/* 456 */     return this.appRequestUrl;
/*     */   }
/*     */   
/*     */   public void setAppRequestUrl(String appRequestUrl) {
/* 460 */     this.appRequestUrl = appRequestUrl;
/*     */   }
/*     */   
/*     */   public String getEncryptTrackCertPath() {
/* 464 */     return this.encryptTrackCertPath;
/*     */   }
/*     */   
/*     */   public void setEncryptTrackCertPath(String encryptTrackCertPath) {
/* 468 */     this.encryptTrackCertPath = encryptTrackCertPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SDKConfig(String rootPath)
/*     */   {
/* 475 */     SDKConfig configs = getConfig();
/* 476 */     configs.rootPath = rootPath;
/* 477 */     if (StringUtils.isNotBlank(rootPath)) {
/* 478 */       configs.loadPropertiesFromPath(rootPath);
/*     */     } else {
/* 480 */       configs.loadPropertiesFromSrc();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public SDKConfig() {}
/*     */   
/*     */   static
/*     */   {
/* 489 */     getConfig().loadPropertiesFromSrc();
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdk\SDKConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */