/*     */ package com.unionpay.acp.sdk;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpClient
/*     */ {
/*     */   private URL url;
/*     */   private int connectionTimeout;
/*     */   private int readTimeOut;
/*     */   private String result;
/*     */   
/*     */   public String getResult()
/*     */   {
/*  64 */     return this.result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResult(String result)
/*     */   {
/*  72 */     this.result = result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpClient(String url, int connectionTimeout, int readTimeOut)
/*     */   {
/*     */     try
/*     */     {
/*  83 */       this.url = new URL(url);
/*  84 */       this.connectionTimeout = connectionTimeout;
/*  85 */       this.readTimeOut = readTimeOut;
/*     */     } catch (MalformedURLException e) {
/*  87 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int send(Map<String, String> data, String encoding)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 100 */       HttpURLConnection httpURLConnection = createConnection(encoding);
/* 101 */       if (null == httpURLConnection) {
/* 102 */         throw new Exception("创建联接失败");
/*     */       }
/* 104 */       requestServer(httpURLConnection, getRequestParamString(data, encoding), encoding);
/*     */       
/* 106 */       this.result = response(httpURLConnection, encoding);
/* 107 */       return httpURLConnection.getResponseCode();
/*     */     } catch (Exception e) {
/* 109 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void requestServer(URLConnection connection, String message, String encoder)
/*     */     throws Exception
/*     */   {
/* 122 */     PrintStream out = null;
/*     */     try {
/* 124 */       connection.connect();
/* 125 */       out = new PrintStream(connection.getOutputStream(), false, encoder);
/* 126 */       out.print(message);
/* 127 */       out.flush();
/*     */     } catch (Exception e) {
/* 129 */       throw e;
/*     */     } finally {
/* 131 */       if (null != out) {
/* 132 */         out.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String response(HttpURLConnection connection, String encoding)
/*     */     throws URISyntaxException, IOException, Exception
/*     */   {
/* 148 */     InputStream in = null;
/* 149 */     StringBuilder sb = new StringBuilder(1024);
/*     */     try {
/* 151 */       if (200 == connection.getResponseCode()) {
/* 152 */         in = connection.getInputStream();
/* 153 */         sb.append(IOUtils.toString(in, encoding));
/*     */       } else {
/* 155 */         in = connection.getErrorStream();
/* 156 */         sb.append(IOUtils.toString(in, encoding));
/*     */       }
/* 158 */       return sb.toString();
/*     */     } catch (Exception e) {
/* 160 */       throw e;
/*     */     }
/*     */     finally {
/* 163 */       if (null != in) {
/* 164 */         in.close();
/*     */       }
/* 166 */       if (null != connection) {
/* 167 */         connection.disconnect();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HttpURLConnection createConnection(String encoding)
/*     */     throws ProtocolException
/*     */   {
/* 179 */     HttpURLConnection httpURLConnection = null;
/*     */     try {
/* 181 */       httpURLConnection = (HttpURLConnection)this.url.openConnection();
/*     */     } catch (IOException e) {
/* 183 */       e.printStackTrace();
/* 184 */       return null;
/*     */     }
/* 186 */     httpURLConnection.setConnectTimeout(this.connectionTimeout);
/* 187 */     httpURLConnection.setReadTimeout(this.readTimeOut);
/* 188 */     httpURLConnection.setDoInput(true);
/* 189 */     httpURLConnection.setDoOutput(true);
/* 190 */     httpURLConnection.setUseCaches(false);
/* 191 */     httpURLConnection.setRequestProperty("Content-type", "application/x-www-form-urlencoded;charset=" + encoding);
/*     */     
/* 193 */     httpURLConnection.setRequestMethod("POST");
/* 194 */     if ("https".equalsIgnoreCase(this.url.getProtocol())) {
/* 195 */       HttpsURLConnection husn = (HttpsURLConnection)httpURLConnection;
/* 196 */       husn.setSSLSocketFactory(new BaseHttpSSLSocketFactory());
/* 197 */       husn.setHostnameVerifier(new BaseHttpSSLSocketFactory.TrustAnyHostnameVerifier());
/* 198 */       return husn;
/*     */     }
/* 200 */     return httpURLConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getRequestParamString(Map<String, String> requestParam, String coder)
/*     */   {
/* 211 */     if ((null == coder) || ("".equals(coder))) {
/* 212 */       coder = "UTF-8";
/*     */     }
/* 214 */     StringBuffer sf = new StringBuffer("");
/* 215 */     String reqstr = "";
/* 216 */     if ((null != requestParam) && (0 != requestParam.size())) {
/* 217 */       for (Map.Entry<String, String> en : requestParam.entrySet()) {
/*     */         try {
/* 219 */           sf.append((String)en.getKey() + "=" + ((null == en.getValue()) || ("".equals(en.getValue())) ? "" : URLEncoder.encode((String)en.getValue(), coder)) + "&");
/*     */ 
/*     */         }
/*     */         catch (UnsupportedEncodingException e)
/*     */         {
/* 224 */           e.printStackTrace();
/* 225 */           return "";
/*     */         }
/*     */       }
/* 228 */       reqstr = sf.substring(0, sf.length() - 1);
/*     */     }
/* 230 */     return reqstr;
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdk\HttpClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */