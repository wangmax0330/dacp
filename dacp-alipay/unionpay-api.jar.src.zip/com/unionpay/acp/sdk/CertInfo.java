/*    */ package com.unionpay.acp.sdk;
/*    */ 
/*    */ import java.security.KeyStore;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertInfo
/*    */ {
/*    */   private String certPath;
/*    */   private String password;
/*    */   private String keyType;
/*    */   private KeyStore keyStore;
/*    */   
/*    */   public KeyStore getKeyStore()
/*    */   {
/* 32 */     return this.keyStore;
/*    */   }
/*    */   
/*    */   public void setKeyStore(KeyStore keyStore) {
/* 36 */     this.keyStore = keyStore;
/*    */   }
/*    */   
/*    */   public String getCertPath() {
/* 40 */     return this.certPath;
/*    */   }
/*    */   
/*    */   public void setCertPath(String certPath) {
/* 44 */     this.certPath = certPath;
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 48 */     return this.password;
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 52 */     this.password = password;
/*    */   }
/*    */   
/*    */   public String getKeyType() {
/* 56 */     return this.keyType;
/*    */   }
/*    */   
/*    */   public void setKeyType(String keyType) {
/* 60 */     this.keyType = keyType;
/*    */   }
/*    */   
/*    */   public CertInfo(String certPath, String password, String keyType)
/*    */   {
/* 65 */     this.certPath = certPath;
/* 66 */     this.password = password;
/* 67 */     this.keyType = keyType;
/*    */   }
/*    */   
/*    */   public CertInfo() {}
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\sdk\CertInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */