/*    */ package com.unionpay.acp.gwj.domain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Area
/*    */ {
/*    */   private String code;
/*    */   
/*    */ 
/*    */ 
/*    */   private String name;
/*    */   
/*    */ 
/*    */   private Area[] areas;
/*    */   
/*    */ 
/*    */ 
/*    */   public String getCode()
/*    */   {
/* 21 */     return this.code;
/*    */   }
/*    */   
/*    */   public void setCode(String code) {
/* 25 */     this.code = code;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 29 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 33 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Area[] getAreas() {
/* 37 */     return this.areas;
/*    */   }
/*    */   
/*    */   public void setAreas(Area[] areas) {
/* 41 */     this.areas = areas;
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\domain\Area.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */