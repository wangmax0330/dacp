/*    */ package com.unionpay.acp.gwj.domain;
/*    */ 
/*    */ 
/*    */ public class Biz
/*    */ {
/*    */   private String code;
/*    */   
/*    */   private String action;
/*    */   private String title;
/*    */   private FormItem[] form;
/*    */   
/*    */   public String getCode()
/*    */   {
/* 14 */     return this.code;
/*    */   }
/*    */   
/*    */   public void setCode(String code) {
/* 18 */     this.code = code;
/*    */   }
/*    */   
/*    */   public String getAction() {
/* 22 */     return this.action;
/*    */   }
/*    */   
/*    */   public void setAction(String action) {
/* 26 */     this.action = action;
/*    */   }
/*    */   
/*    */   public String getTitle() {
/* 30 */     return this.title;
/*    */   }
/*    */   
/*    */   public void setTitle(String title) {
/* 34 */     this.title = title;
/*    */   }
/*    */   
/*    */   public FormItem[] getForm() {
/* 38 */     return this.form;
/*    */   }
/*    */   
/*    */   public void setForm(FormItem[] form) {
/* 42 */     this.form = form;
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\domain\Biz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */