/*    */ package com.unionpay.acp.gwj.domain;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormItem
/*    */ {
/*    */   private String type;
/*    */   private String label;
/*    */   private Rule rule;
/*    */   private String name;
/*    */   private String value;
/*    */   private String action;
/*    */   private ArrayList<Rule> rules;
/*    */   private ArrayList<FormItem> options;
/*    */   private String vid;
/*    */   
/*    */   public ArrayList<Rule> getRules()
/*    */   {
/* 24 */     return this.rules;
/*    */   }
/*    */   
/* 27 */   public void setRules(ArrayList<Rule> rules) { this.rules = rules; }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getType()
/*    */   {
/* 34 */     return this.type;
/*    */   }
/*    */   
/* 37 */   public void setType(String type) { this.type = type; }
/*    */   
/*    */   public String getLabel() {
/* 40 */     return this.label;
/*    */   }
/*    */   
/* 43 */   public void setLabel(String label) { this.label = label; }
/*    */   
/*    */ 
/*    */ 
/*    */   public Rule getRule()
/*    */   {
/* 49 */     return this.rule;
/*    */   }
/*    */   
/* 52 */   public void setRule(Rule rule) { this.rule = rule; }
/*    */   
/*    */   public String getName() {
/* 55 */     return this.name;
/*    */   }
/*    */   
/* 58 */   public void setName(String name) { this.name = name; }
/*    */   
/*    */   public String getValue() {
/* 61 */     return this.value;
/*    */   }
/*    */   
/* 64 */   public void setValue(String value) { this.value = value; }
/*    */   
/*    */   public ArrayList<FormItem> getOptions()
/*    */   {
/* 68 */     return this.options;
/*    */   }
/*    */   
/* 71 */   public void setOptions(ArrayList<FormItem> options) { this.options = options; }
/*    */   
/*    */   public String getVid() {
/* 74 */     return this.vid;
/*    */   }
/*    */   
/* 77 */   public void setVid(String vid) { this.vid = vid; }
/*    */   
/*    */   public String getAction() {
/* 80 */     return this.action;
/*    */   }
/*    */   
/* 83 */   public void setAction(String action) { this.action = action; }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\domain\FormItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */