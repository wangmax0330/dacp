/*     */ package com.unionpay.acp.gwj.domain;
/*     */ 
/*     */ import com.unionpay.acp.gwj.exception.RuleValidateException;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rule
/*     */ {
/*  21 */   private boolean required = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int maxLength;
/*     */   
/*     */ 
/*     */ 
/*     */   private int minLength;
/*     */   
/*     */ 
/*     */ 
/*     */   private int length;
/*     */   
/*     */ 
/*     */ 
/*     */   private String equals;
/*     */   
/*     */ 
/*     */ 
/*     */   private String isDate;
/*     */   
/*     */ 
/*     */ 
/*     */   private int decimal;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate(String name, String label, String value, Map<String, Object> requestMap)
/*     */   {
/*  53 */     validateRequired(name, label, value);
/*  54 */     validateMaxLength(name, label, value);
/*  55 */     validateMinLength(name, label, value);
/*  56 */     validateLength(name, label, value);
/*  57 */     validateEquals(name, label, value, requestMap);
/*  58 */     validateIsDate(name, label, value);
/*  59 */     validateDecimal(name, label, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void validateRequired(String name, String label, String value)
/*     */   {
/*  66 */     if (!this.required) {
/*  67 */       return;
/*     */     }
/*     */     
/*  70 */     if (StringUtils.isEmpty(value)) {
/*  71 */       throw new RuleValidateException(name, "01", label + "不能为空");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateMaxLength(String name, String label, String value)
/*     */   {
/*  80 */     if ((this.maxLength > 0) && 
/*  81 */       (value.length() > this.maxLength)) {
/*  82 */       throw new RuleValidateException(name, "02", label + "输入长度不能大于" + this.maxLength);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateMinLength(String name, String label, String value)
/*     */   {
/*  93 */     if ((this.minLength > 0) && 
/*  94 */       (value.length() < this.minLength)) {
/*  95 */       throw new RuleValidateException(name, "03", label + "输入长度不能小于" + this.minLength);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateLength(String name, String label, String value)
/*     */   {
/* 106 */     if ((this.length > 0) && 
/* 107 */       (value.length() != this.length)) {
/* 108 */       throw new RuleValidateException(name, "04", label + "输入长度须等于" + this.length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateEquals(String name, String label, String value, Map<String, Object> contextMap)
/*     */   {
/* 120 */     if (!StringUtils.isEmpty(this.equals)) {
/* 121 */       String expectEqualItemName = this.equals.substring("${".length(), this.equals.length() - 1);
/*     */       
/* 123 */       String expectValue = (String)contextMap.get(expectEqualItemName);
/* 124 */       if (!value.equals(expectValue)) {
/* 125 */         throw new RuleValidateException(name, "05", label + "两次输入的值不相同");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateIsDate(String name, String label, String value)
/*     */   {
/* 135 */     if (!StringUtils.isEmpty(this.isDate))
/*     */     {
/* 137 */       SimpleDateFormat s = new SimpleDateFormat(this.isDate);
/* 138 */       s.setLenient(false);
/*     */       try {
/* 140 */         s.parse(value);
/*     */       } catch (ParseException e) {
/* 142 */         throw new RuleValidateException(name, "06", label + "时间格式非法");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateDecimal(String name, String label, String value)
/*     */   {
/* 153 */     if (this.decimal > 0)
/*     */     {
/* 155 */       if (StringUtils.isEmpty(value)) {
/* 156 */         throw new RuleValidateException(name, "07", label + "不能为空");
/*     */       }
/*     */       
/*     */ 
/* 160 */       BigDecimal bd = new BigDecimal(value);
/* 161 */       if (bd.doubleValue() > 9.99999999999E9D) {
/* 162 */         throw new RuleValidateException(name, "07", label + "的值非法");
/*     */       }
/*     */       
/*     */ 
/* 166 */       int index = value.indexOf('.');
/* 167 */       if ((index > 0) && (value.length() - index > this.decimal + 1)) {
/* 168 */         throw new RuleValidateException(name, "07", label + "不能超过" + this.decimal + "位小数");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRequired()
/*     */   {
/* 177 */     return this.required;
/*     */   }
/*     */   
/*     */   public void setRequired(boolean required) {
/* 181 */     this.required = required;
/*     */   }
/*     */   
/*     */   public int getMaxLength() {
/* 185 */     return this.maxLength;
/*     */   }
/*     */   
/*     */   public void setMaxLength(int maxLength) {
/* 189 */     this.maxLength = maxLength;
/*     */   }
/*     */   
/*     */   public int getMinLength() {
/* 193 */     return this.minLength;
/*     */   }
/*     */   
/*     */   public void setMinLength(int minLength) {
/* 197 */     this.minLength = minLength;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 201 */     return this.length;
/*     */   }
/*     */   
/*     */   public void setLength(int length) {
/* 205 */     this.length = length;
/*     */   }
/*     */   
/*     */   public String getEquals() {
/* 209 */     return this.equals;
/*     */   }
/*     */   
/*     */   public void setEquals(String equals) {
/* 213 */     this.equals = equals;
/*     */   }
/*     */   
/*     */   public String getIsDate() {
/* 217 */     return this.isDate;
/*     */   }
/*     */   
/*     */   public void setIsDate(String isDate) {
/* 221 */     this.isDate = isDate;
/*     */   }
/*     */   
/*     */   public int getDecimal() {
/* 225 */     return this.decimal;
/*     */   }
/*     */   
/*     */   public void setDecimal(int decimal) {
/* 229 */     this.decimal = decimal;
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\domain\Rule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */