/*    */ package com.unionpay.acp.gwj.domain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Category
/*    */ {
/*    */   private String code;
/*    */   
/*    */ 
/*    */ 
/*    */   private String name;
/*    */   
/*    */ 
/*    */ 
/*    */   private String type;
/*    */   
/*    */ 
/*    */ 
/*    */   private Bussiness[] categories;
/*    */   
/*    */ 
/*    */ 
/*    */   public String getCode()
/*    */   {
/* 26 */     return this.code;
/*    */   }
/*    */   
/*    */   public void setCode(String code) {
/* 30 */     this.code = code;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 34 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 38 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getType() {
/* 42 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(String type) {
/* 46 */     this.type = type;
/*    */   }
/*    */   
/*    */   public Bussiness[] getCategories() {
/* 50 */     return this.categories;
/*    */   }
/*    */   
/*    */   public void setCategories(Bussiness[] categories) {
/* 54 */     this.categories = categories;
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\domain\Category.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */