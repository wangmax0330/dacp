/*    */ package com.unionpay.acp.gwj.domain;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bussiness
/*    */ {
/*    */   private String code;
/*    */   
/*    */ 
/*    */   private String name;
/*    */   
/*    */ 
/*    */   public String getCode()
/*    */   {
/* 15 */     return this.code;
/*    */   }
/*    */   
/*    */   public void setCode(String code) {
/* 19 */     this.code = code;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 23 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 27 */     this.name = name;
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\domain\Bussiness.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */