/*    */ package com.unionpay.acp.gwj.vo;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransParams
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String v;
/*    */   private String cmd;
/*    */   private String resp;
/*    */   private String msg;
/*    */   private HashMap<String, Object> params;
/*    */   
/*    */   public String getV()
/*    */   {
/* 24 */     return this.v;
/*    */   }
/*    */   
/*    */   public void setV(String v) {
/* 28 */     this.v = v;
/*    */   }
/*    */   
/*    */   public String getCmd() {
/* 32 */     return this.cmd;
/*    */   }
/*    */   
/*    */   public void setCmd(String cmd) {
/* 36 */     this.cmd = cmd;
/*    */   }
/*    */   
/*    */   public String getResp() {
/* 40 */     return this.resp;
/*    */   }
/*    */   
/*    */   public void setResp(String resp) {
/* 44 */     this.resp = resp;
/*    */   }
/*    */   
/*    */   public String getMsg() {
/* 48 */     return this.msg;
/*    */   }
/*    */   
/*    */   public void setMsg(String msg) {
/* 52 */     this.msg = msg;
/*    */   }
/*    */   
/*    */   public HashMap<String, Object> getParams() {
/* 56 */     return this.params;
/*    */   }
/*    */   
/*    */   public void setParams(HashMap<String, Object> params) {
/* 60 */     this.params = params;
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\vo\TransParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */