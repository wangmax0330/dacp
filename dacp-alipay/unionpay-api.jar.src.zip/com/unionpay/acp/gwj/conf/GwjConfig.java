/*    */ package com.unionpay.acp.gwj.conf;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.util.PropertyResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GwjConfig
/*    */ {
/*    */   public static String GWJ_URL;
/*    */   public static String GWJ_CID;
/*    */   public static String GWJ_CODE;
/*    */   private static final String KEY_GWJ_URL = "gwj.url";
/*    */   private static final String KEY_CID = "gwj-cid";
/*    */   private static final String KEY_CODE = "gwj-code";
/*    */   private static final String CONF_FILE_NAME = "acp_sdk.properties";
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 37 */       InputStream fis = GwjConfig.class.getClassLoader().getResourceAsStream("acp_sdk.properties");
/* 38 */       PropertyResourceBundle props = new PropertyResourceBundle(fis);
/* 39 */       GWJ_URL = props.getString("gwj.url");
/* 40 */       GWJ_CID = props.getString("gwj-cid");
/* 41 */       GWJ_CODE = props.getString("gwj-code");
/*    */     } catch (Exception e) {
/* 43 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */   public static void setConfig(String gwjUrl, String cid, String code) {
/* 48 */     GWJ_URL = gwjUrl;
/* 49 */     GWJ_CID = cid;
/* 50 */     GWJ_CODE = code;
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\conf\GwjConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */