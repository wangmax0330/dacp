package com.unionpay.acp.gwj.conf;

public class GwjConstants
{
  public static final String PREFIX = "/s";
  public static final String ENTRY = "/entry";
  public static final String SUFFIX_URL_AREAS = "/areas";
  public static final String SUFFIX_URL_CATEGORIES = "/categories";
  public static final String SUFFIX_URL_BIZ = "/biz";
  public static final String SUFFIX_URL_GETCAPTCHA = "?getcaptcha";
  public static final String SUFFIX_URL_GETVID = "?getvid";
}


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\conf\GwjConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */