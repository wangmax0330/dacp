/*    */ package com.unionpay.acp.gwj.exception;
/*    */ 
/*    */ public class RuleValidateException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   public static final String REQUIRED_ERROR = "01";
/*    */   public static final String MAXLENGTH_ERROR = "02";
/*    */   public static final String MINLENGTH_ERROR = "03";
/*    */   public static final String LENGTH_ERROR = "04";
/*    */   public static final String EQUALS_ERROR = "05";
/*    */   public static final String ISDATE_ERROR = "06";
/*    */   public static final String DECIMAL_ERROR = "07";
/*    */   public String name;
/*    */   public String code;
/*    */   public String message;
/*    */   
/*    */   public RuleValidateException(String name, String code, String message)
/*    */   {
/* 20 */     super(message);
/* 21 */     this.name = name;
/* 22 */     this.code = code;
/* 23 */     this.message = message;
/*    */   }
/*    */   
/*    */   public String getCode() {
/* 27 */     return this.code;
/*    */   }
/*    */   
/*    */   public void setCode(String code) {
/* 31 */     this.code = code;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 35 */     return this.message;
/*    */   }
/*    */   
/*    */   public void setMessage(String message) {
/* 39 */     this.message = message;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 43 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 47 */     this.name = name;
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\exception\RuleValidateException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */