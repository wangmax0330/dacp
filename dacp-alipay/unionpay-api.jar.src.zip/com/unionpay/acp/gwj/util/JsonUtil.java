/*    */ package com.unionpay.acp.gwj.util;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.codehaus.jackson.map.ObjectMapper;
/*    */ import org.codehaus.jackson.map.SerializationConfig;
/*    */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*    */ import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonUtil
/*    */ {
/* 17 */   private static final Logger logger = Logger.getLogger(JsonUtil.class);
/*    */   
/* 19 */   private static final ObjectMapper mapper = new ObjectMapper();
/*    */   private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
/*    */   
/*    */   static {
/* 23 */     mapper.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
/* 24 */     mapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, true);
/* 25 */     mapper.getSerializationConfig().setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
/*    */     
/* 27 */     mapper.setSerializationInclusion(JsonSerialize.Inclusion.NON_NULL);
/*    */   }
/*    */   
/*    */   public static <T> T fromJson(String json, Class<T> t)
/*    */   {
/* 32 */     if (json == null) {
/* 33 */       return null;
/*    */     }
/*    */     try {
/* 36 */       return (T)mapper.readValue(json, t);
/*    */     } catch (Exception e) {
/* 38 */       logger.info("Cannot parse json string to Object. Json: <" + json + ">, Object class: <" + t.getName() + ">.", e);
/*    */     }
/*    */     
/* 41 */     return null;
/*    */   }
/*    */   
/*    */   public static <T> T fromJsonWithException(String json, Class<T> t) {
/*    */     try {
/* 46 */       return (T)mapper.readValue(json, t);
/*    */     } catch (Exception e) {
/* 48 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public static <T> T fromMap(Map<?, ?> map, Class<T> t)
/*    */   {
/* 54 */     if (map == null) {
/* 55 */       return null;
/*    */     }
/*    */     try {
/* 58 */       return (T)mapper.readValue(toJson(map), t);
/*    */     } catch (Exception e) {
/* 60 */       logger.info("Cannot parse map to Object. Map: <" + map + ">, Object class: <" + t.getName() + ">.", e);
/*    */     }
/*    */     
/* 63 */     return null;
/*    */   }
/*    */   
/*    */   public static String toJson(Object obj)
/*    */   {
/*    */     try {
/* 69 */       return mapper.writeValueAsString(obj);
/*    */     } catch (Exception e) {
/* 71 */       logger.warn(e);
/*    */     }
/* 73 */     return "{}";
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\util\JsonUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */