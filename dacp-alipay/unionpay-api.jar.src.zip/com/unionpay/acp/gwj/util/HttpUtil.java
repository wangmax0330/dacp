/*     */ package com.unionpay.acp.gwj.util;
/*     */ 
/*     */ import com.unionpay.acp.gwj.conf.GwjConfig;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
/*     */ import org.apache.commons.httpclient.HttpClient;
/*     */ import org.apache.commons.httpclient.HttpConnectionManager;
/*     */ import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
/*     */ import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
/*     */ import org.apache.commons.httpclient.methods.GetMethod;
/*     */ import org.apache.commons.httpclient.methods.PostMethod;
/*     */ import org.apache.commons.httpclient.methods.RequestEntity;
/*     */ import org.apache.commons.httpclient.params.HttpClientParams;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpUtil
/*     */ {
/*  25 */   private static final Logger logger = Logger.getLogger(HttpUtil.class);
/*     */   
/*     */   public static String encoding;
/*     */   
/*  29 */   private static String GWJ_CID = "gwj-cid";
/*  30 */   private static String GWJ_CODE = "gwj-code";
/*     */   
/*     */ 
/*     */   private static final HttpConnectionManager connectionManager;
/*     */   
/*     */ 
/*     */   static
/*     */   {
/*  38 */     HttpConnectionManagerParams params = loadHttpConfFromFile();
/*     */     
/*  40 */     connectionManager = new MultiThreadedHttpConnectionManager();
/*     */     
/*  42 */     connectionManager.setParams(params); }
/*     */   
/*  44 */   private static final HttpClient client = new HttpClient(connectionManager);
/*     */   
/*     */   private static HttpConnectionManagerParams loadHttpConfFromFile()
/*     */   {
/*  48 */     Properties p = new Properties();
/*     */     try {
/*  50 */       p.load(HttpUtil.class.getResourceAsStream(HttpUtil.class.getSimpleName().toLowerCase() + ".properties"));
/*     */     }
/*     */     catch (IOException e) {}
/*     */     
/*  54 */     encoding = p.getProperty("http.content.encoding");
/*     */     
/*  56 */     HttpConnectionManagerParams params = new HttpConnectionManagerParams();
/*  57 */     params.setConnectionTimeout(Integer.parseInt(p.getProperty("http.connection.timeout")));
/*  58 */     params.setSoTimeout(Integer.parseInt(p.getProperty("http.so.timeout")));
/*  59 */     params.setStaleCheckingEnabled(Boolean.parseBoolean(p.getProperty("http.stale.check.enabled")));
/*  60 */     params.setTcpNoDelay(Boolean.parseBoolean(p.getProperty("http.tcp.no.delay")));
/*  61 */     params.setDefaultMaxConnectionsPerHost(Integer.parseInt(p.getProperty("http.default.max.connections.per.host")));
/*  62 */     params.setMaxTotalConnections(Integer.parseInt(p.getProperty("http.max.total.connections")));
/*  63 */     params.setParameter("http.method.retry-handler", new DefaultHttpMethodRetryHandler(0, false));
/*  64 */     return params;
/*     */   }
/*     */   
/*     */   public static String post(String url, String encoding, String content)
/*     */   {
/*     */     try {
/*  70 */       byte[] resp = post(url, content.getBytes(encoding));
/*  71 */       if (null == resp) {
/*  72 */         return null;
/*     */       }
/*  74 */       return new String(resp, encoding);
/*     */     } catch (UnsupportedEncodingException e) {}
/*  76 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public static String post(String url, String content)
/*     */   {
/*  82 */     return post(url, encoding, content);
/*     */   }
/*     */   
/*     */   public static byte[] post(String url, byte[] content)
/*     */   {
/*     */     try {
/*  88 */       return post(url, new ByteArrayRequestEntity(content));
/*     */     }
/*     */     catch (Exception e) {
/*  91 */       logger.warn("Catch exception while post to url [" + url + "]", e); }
/*  92 */     return null;
/*     */   }
/*     */   
/*     */   public static byte[] post(String url, RequestEntity requestEntity)
/*     */     throws Exception
/*     */   {
/*  98 */     PostMethod method = new PostMethod(url);
/*  99 */     method.addRequestHeader("Connection", "Keep-Alive");
/* 100 */     method.getParams().setCookiePolicy("ignoreCookies");
/* 101 */     method.getParams().setParameter("http.method.retry-handler", new DefaultHttpMethodRetryHandler(0, false));
/* 102 */     method.setRequestEntity(requestEntity);
/*     */     
/* 104 */     method.addRequestHeader("Content-Type", "application/x-www-form-urlencoded");
/* 105 */     method.setRequestHeader(GWJ_CID, GwjConfig.GWJ_CID);
/* 106 */     method.setRequestHeader(GWJ_CODE, GwjConfig.GWJ_CODE);
/*     */     try
/*     */     {
/* 109 */       int statusCode = client.executeMethod(method);
/* 110 */       byte[] arrayOfByte; if (statusCode != 200) {
/* 111 */         logger.warn("Http response status is not OK [" + statusCode + "]");
/* 112 */         return null;
/*     */       }
/* 114 */       return method.getResponseBody();
/*     */     }
/*     */     finally {
/* 117 */       method.releaseConnection();
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getAsString(String url)
/*     */   {
/*     */     try {
/* 124 */       return new String(get(url), encoding);
/*     */     } catch (Exception e) {
/* 126 */       logger.warn("Catch exception while get method to url[" + url + "]", e);
/*     */     }
/*     */     
/*     */ 
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   public static byte[] get(String url)
/*     */   {
/* 135 */     client.getParams().setCookiePolicy("ignoreCookies");
/*     */     
/*     */ 
/* 138 */     GetMethod method = new GetMethod(url);
/* 139 */     method.setRequestHeader(GWJ_CID, GwjConfig.GWJ_CID);
/* 140 */     method.setRequestHeader(GWJ_CODE, GwjConfig.GWJ_CODE);
/*     */     try
/*     */     {
/* 143 */       int statusCode = client.executeMethod(method);
/* 144 */       if (statusCode != 200) {
/* 145 */         logger.warn("Http response status is not OK [" + statusCode + "]");
/* 146 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 150 */       return method.getResponseBody();
/*     */     } catch (Exception e) {
/*     */       byte[] arrayOfByte;
/* 153 */       logger.warn("Catch exception while get to url [" + url + "]", e);
/* 154 */       return null;
/*     */     } finally {
/* 156 */       method.releaseConnection();
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\util\HttpUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */