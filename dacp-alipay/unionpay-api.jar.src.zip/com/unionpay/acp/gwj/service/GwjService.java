/*    */ package com.unionpay.acp.gwj.service;
/*    */ 
/*    */ import com.unionpay.acp.gwj.conf.GwjConfig;
/*    */ import com.unionpay.acp.gwj.domain.Biz;
/*    */ import com.unionpay.acp.gwj.util.HttpUtil;
/*    */ import com.unionpay.acp.gwj.util.JsonUtil;
/*    */ import com.unionpay.acp.gwj.vo.TransParams;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GwjService
/*    */ {
/*    */   public static TransParams transaction(TransParams transParams)
/*    */   {
/* 77 */     Map<String, String> params = new HashMap();
/* 78 */     params.put("billDetail", JsonUtil.toJson(transParams));
/*    */     
/* 80 */     String resString = HttpUtil.post(GwjConfig.GWJ_URL + "/entry", JsonUtil.toJson(transParams));
/* 81 */     return (TransParams)JsonUtil.fromJson(resString, TransParams.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Biz getBiz(String bussCode)
/*    */   {
/* 92 */     byte[] get = HttpUtil.get(GwjConfig.GWJ_URL + "/s" + "/biz" + "/" + bussCode);
/* 93 */     return (Biz)JsonUtil.fromJson(new String(get), Biz.class);
/*    */   }
/*    */ }


/* Location:              F:\Temp\新建文件夹\unionpay-api.jar!\com\unionpay\acp\gwj\service\GwjService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */